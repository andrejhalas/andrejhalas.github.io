import { spawnSync } from "node:child_process";
const configured = process.env.SITE_URL;
if (!configured)
  throw new Error(
    "Set SITE_URL to the ACTUAL assigned Cloudflare Pages origin before publishing.",
  );
const url = new URL(configured);
if (
  url.protocol !== "https:" ||
  !url.hostname.endsWith(".pages.dev") ||
  url.pathname !== "/" ||
  url.search ||
  url.hash ||
  url.username ||
  url.password
) {
  throw new Error(
    "SITE_URL must be the actual https://<assigned-project>.pages.dev origin, without a path.",
  );
}
const result = spawnSync("npm", ["run", "build"], {
  stdio: "inherit",
  env: process.env,
});
process.exit(result.status ?? 1);
