import { test } from "node:test";
import assert from "node:assert/strict";
import { Window, HTMLButtonElement, HTMLElement } from "happy-dom";
import { readFileSync } from "node:fs";
import { attemptPopup } from "../src/scripts/popup-test";
test("popup outcomes include returned, null, closed and throwing handles", () => {
  const child = { closed: false, opener: {} } as unknown as globalThis.Window;
  assert.equal(attemptPopup(() => child).outcome, "allowed");
  assert.equal(child.opener, null);
  assert.equal(attemptPopup(() => null).outcome, "likely_blocked");
  assert.equal(
    attemptPopup(() => ({ closed: true }) as globalThis.Window).outcome,
    "likely_blocked",
  );
  assert.equal(
    attemptPopup(() => {
      throw new Error("webview denied");
    }).outcome,
    "inconclusive",
  );
});
test("popup controls open only on request, delayed test cancels cleanly", async () => {
  const dom = new Window({ url: "http://localhost:4321/popup-blocker-test/" });
  dom.document.write(
    readFileSync("dist/popup-blocker-test/index.html", "utf8"),
  );
  Object.assign(globalThis, {
    document: dom.document,
    window: dom,
    CustomEvent: dom.CustomEvent,
  });
  let opens = 0,
    closed = 0;
  Object.defineProperty(dom, "open", {
    value: () => {
      opens++;
      return {
        closed: false,
        opener: {},
        close() {
          closed++;
        },
      };
    },
  });
  const { initPopupTest } = await import("../src/scripts/popup-test");
  initPopupTest();
  assert.equal(opens, 0);
  dom.document.querySelector<HTMLButtonElement>("#test-direct")!.click();
  assert.equal(opens, 1);
  assert.match(
    dom.document.querySelector("#test-result")!.textContent!,
    /Allowed/,
  );
  dom.document.querySelector<HTMLButtonElement>("#test-delayed")!.click();
  assert.equal(closed, 1);
  assert.equal(opens, 1);
  assert.equal(
    dom.document.querySelector<HTMLButtonElement>("#test-direct")!.disabled,
    true,
  );
  dom.document.querySelector<HTMLButtonElement>("#test-cancel")!.click();
  assert.equal(opens, 1);
  assert.match(
    dom.document.querySelector("#test-result")!.textContent!,
    /canceled/,
  );
  assert.equal(
    dom.document.querySelector<HTMLButtonElement>("#test-direct")!.disabled,
    false,
  );
  const originalTimer = globalThis.setTimeout;
  let delayedCallback: (() => void) | undefined;
  globalThis.setTimeout = ((callback: () => void, delay: number) => {
    assert.equal(delay, 6000);
    delayedCallback = callback;
    return 1 as unknown as ReturnType<typeof setTimeout>;
  }) as typeof setTimeout;
  try {
    dom.document.querySelector<HTMLButtonElement>("#test-delayed")!.click();
    assert.equal(opens, 1);
    assert.ok(delayedCallback);
    delayedCallback();
    assert.equal(opens, 2);
    assert.match(
      dom.document.querySelector("#test-result")!.textContent!,
      /delayed attempt/,
    );
  } finally {
    globalThis.setTimeout = originalTimer;
  }
  dom.document.querySelector<HTMLButtonElement>("#test-close")!.click();
  await dom.happyDOM.close();
});
test("simulator inspection, safe exit, destruction and restart", async () => {
  const dom = new Window({ url: "http://localhost:4321/fake-virus-popup/" });
  dom.document.write(readFileSync("dist/fake-virus-popup/index.html", "utf8"));
  Object.assign(globalThis, {
    document: dom.document,
    window: dom,
    CustomEvent: dom.CustomEvent,
  });
  await import("../src/scripts/simulator");
  dom.document.querySelector<HTMLButtonElement>("#sim-start")!.click();
  assert.equal(
    dom.document.querySelector<HTMLElement>("#simulation")!.hidden,
    false,
  );
  dom.document
    .querySelector<HTMLButtonElement>('[data-tactic="claims"]')!
    .click();
  assert.match(
    dom.document.querySelector("#tactic-info")!.textContent!,
    /normal web page/,
  );
  dom.document.querySelector<HTMLButtonElement>("#sim-smash")!.click();
  assert.ok(
    dom.document.querySelector("#warning")!.classList.contains("smashed"),
  );
  dom.document.querySelector<HTMLButtonElement>("#sim-exit")!.click();
  assert.equal(
    dom.document.querySelector<HTMLElement>("#simulation")!.hidden,
    true,
  );
  dom.document.querySelector<HTMLButtonElement>("#sim-start")!.click();
  assert.match(
    dom.document.querySelector("#warning h2")!.textContent!,
    /47 imaginary viruses/,
  );
  assert.equal(
    dom.document.querySelector<HTMLButtonElement>("#sim-smash")!.disabled,
    false,
  );
  await dom.happyDOM.close();
});
test("all six dark patterns respond, fair designs toggle, destruction is reversible", async () => {
  const dom = new Window({
    url: "http://localhost:4321/dark-pattern-examples/",
  });
  dom.document.write(
    readFileSync("dist/dark-pattern-examples/index.html", "utf8"),
  );
  Object.assign(globalThis, { document: dom.document, window: dom });
  await import("../src/scripts/patterns");
  const cards = dom.document.querySelectorAll("[data-pattern]");
  assert.equal(cards.length, 6);
  cards.forEach((card) => {
    card.querySelector<HTMLButtonElement>('[data-action="fair"]')!.click();
    assert.equal(
      card.querySelector<HTMLElement>(".fair-example")!.hidden,
      false,
    );
    card.querySelector<HTMLButtonElement>('[data-action="smash"]')!.click();
    assert.equal(card.querySelector<HTMLElement>(".bad-example")!.hidden, true);
    card.querySelector<HTMLButtonElement>('[data-action="restore"]')!.click();
    assert.equal(
      card.querySelector<HTMLElement>(".bad-example")!.hidden,
      false,
    );
  });
  dom.document
    .querySelector<HTMLButtonElement>('[data-action="bait"]')!
    .click();
  assert.match(
    dom.document.querySelector('[data-pattern="download"] .pattern-output')!
      .textContent!,
    /Nothing downloaded/,
  );
  dom.document
    .querySelector<HTMLButtonElement>('[data-action="refresh"]')!
    .click();
  assert.match(
    dom.document.querySelector("[data-stock]")!.textContent!,
    /Only 1/,
  );
  dom.dispatchEvent(new dom.Event("pagehide"));
  await dom.happyDOM.close();
});
