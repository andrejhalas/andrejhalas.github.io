import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync, readdirSync, statSync } from "node:fs";
import {
  Window,
  HTMLLinkElement,
  HTMLAnchorElement,
  HTMLElement,
} from "happy-dom";
import { join } from "node:path";
test("crawlable HTML, unique metadata, internal links, assets and truthful noindex", () => {
  const base = (process.env.SITE_BASE_PATH || "/").replace(/\/$/, "");
  const paths = [
    "/",
    "/fake-virus-popup/",
    "/popup-blocker-test/",
    "/dark-pattern-examples/",
    "/privacy/",
  ];
  const titles = new Set<string>(),
    descriptions = new Set<string>();
  let origin = "";
  for (const path of paths) {
    const file = "dist" + (path === "/" ? "/index.html" : path + "index.html");
    const dom = new Window();
    dom.document.write(readFileSync(file, "utf8"));
    const d = dom.document;
    const title = d.querySelector("title")!.textContent!,
      description = d
        .querySelector('meta[name="description"]')!
        .getAttribute("content")!;
    assert.ok(title.length > 15);
    assert.ok(description.length > 50);
    titles.add(title);
    descriptions.add(description);
    assert.equal(d.querySelectorAll("h1").length, 1);
    assert.equal(d.documentElement.lang, "en");
    assert.ok(d.querySelector("main"));
    const canonical = d
      .querySelector<HTMLLinkElement>('link[rel="canonical"]')!
      .getAttribute("href")!;
    assert.equal(new URL(canonical).pathname, base + path);
    origin = new URL(canonical).origin;
    assert.equal(
      d.querySelector('meta[property="og:url"]')!.getAttribute("content"),
      canonical,
    );
    assert.ok(d.querySelector('script[type="application/ld+json"]'));
    assert.equal(d.querySelector('script[src*="cloudflareinsights"]'), null);
    if (origin.includes("localhost"))
      assert.ok(
        d.querySelector('meta[name="robots"][content="noindex, nofollow"]'),
      );
    d.querySelectorAll<HTMLAnchorElement>('a[href^="/"]').forEach((a) => {
      const href = a.getAttribute("href")!.slice(base.length);
      assert.ok(
        existsSync("dist" + (href.endsWith("/") ? href + "index.html" : href)),
        `${file} broken link ${href}`,
      );
    });
    d.querySelectorAll<HTMLElement>('[src^="/"],link[href^="/"]').forEach(
      (el) => {
        const asset = (
          el.getAttribute("src") || el.getAttribute("href")!
        ).slice(base.length);
        assert.ok(existsSync("dist" + asset), `Missing asset ${asset}`);
      },
    );
    d.querySelectorAll("button").forEach((b) =>
      assert.ok(
        b.textContent!.trim() || b.getAttribute("aria-label"),
        "Button has an accessible name",
      ),
    );
  }
  assert.equal(titles.size, paths.length);
  assert.equal(descriptions.size, paths.length);
  assert.ok(existsSync("dist/social.png"));
  const sitemap = readFileSync("dist/sitemap.xml", "utf8");
  for (const path of paths) assert.ok(sitemap.includes(origin + base + path));
  assert.ok(!sitemap.includes("/popup-test-window/"));
  assert.match(
    readFileSync("dist/popup-test-window/index.html", "utf8"),
    /noindex/,
  );
});
test("static output contains no ad network or external script by default and stays small", () => {
  const walk = (dir: string): string[] =>
    readdirSync(dir).flatMap((name) => {
      const file = join(dir, name);
      return statSync(file).isDirectory() ? walk(file) : [file];
    });
  const files = walk("dist");
  assert.ok(files.reduce((n, file) => n + statSync(file).size, 0) < 500_000);
  files
    .filter((f) => f.endsWith(".html"))
    .forEach((f) => {
      const html = readFileSync(f, "utf8");
      assert.ok(!/adsbygoogle|doubleclick|googlesyndication/.test(html));
      assert.ok(!/<script[^>]+src="https?:/.test(html));
    });
  const js = files.filter((f) => f.endsWith(".js"));
  assert.ok(js.reduce((n, f) => n + statSync(f).size, 0) < 50_000);
});
