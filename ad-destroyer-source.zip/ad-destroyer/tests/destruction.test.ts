import { test } from "node:test";
import assert from "node:assert/strict";
import { Window } from "happy-dom";
import { readFileSync } from "node:fs";
import { stepShard, Destruction, type Shard } from "../src/scripts/destruction";
import { targetMotion } from "../src/scripts/rules";
test("debris rebounds inside the arena, loses energy on impact and expires", () => {
  const p = {
    x: 2,
    y: 98,
    vx: -200,
    vy: 180,
    angle: 0,
    spin: 4,
    life: 500,
    max: 500,
  } as Shard;
  stepShard(p, 40, 200, 100);
  assert.equal(p.x, 0);
  assert.ok(p.vx > 0);
  assert.equal(p.y, 100);
  assert.ok(p.vy < 0);
  assert.ok(Math.abs(p.vy) < 180);
  assert.ok(p.angle > 0);
  for (let i = 0; i < 20; i++) stepShard(p, 40, 200, 100);
  assert.ok(p.life < 0);
  assert.ok(p.x >= 0 && p.x <= 200);
  assert.ok(p.y <= 100);
});
test("moving targets stay in mobile lanes and increase movement with difficulty", () => {
  for (let t = 0; t < 60000; t += 113) {
    const m = targetMotion(t, 2, 5, true);
    assert.ok(Math.abs(m.x) <= 13);
    assert.ok(Math.abs(m.y) <= 7);
  }
  assert.notDeepEqual(
    targetMotion(0, 0, 1, false),
    targetMotion(2000, 0, 1, false),
  );
  assert.deepEqual(targetMotion(5000, 2, 5, true, true), {
    x: 0,
    y: 0,
    angle: 0,
  });
  assert.ok(
    Math.abs(targetMotion(1200, 0, 5, false).x) >
      Math.abs(targetMotion(1200, 0, 1, false).x),
  );
});
test("destruction effects have hard bounds and reduced motion suppresses debris and beams", () => {
  const fx = new Destruction({} as HTMLCanvasElement, null);
  for (let i = 0; i < 50; i++) fx.hit(100, 100, "#ff83b5", "laser", true);
  assert.equal(fx.sparks.length, 280);
  assert.equal(fx.rings.length, 12);
  assert.equal(fx.beam, 1);
  for (let i = 0; i < 50; i++) fx.label(10, 10, "+100");
  assert.equal(fx.labels.length, 16);
  fx.clear();
  fx.reduced = true;
  fx.hit(50, 50, "#fff", "laser", true);
  fx.shockwave();
  assert.equal(fx.sparks.length, 0);
  assert.equal(fx.rings.length, 0);
  assert.equal(fx.beam, 0);
});
test("rage cannot bypass boss mechanics; held and keyboard targets stop moving; expiry resets combo", async () => {
  const dom = new Window({
    url: "https://andrejhalas.github.io/ad-destroyer/",
  });
  dom.document.write(readFileSync("dist/index.html", "utf8"));
  Object.assign(globalThis, {
    window: dom,
    document: dom.document,
    location: dom.location,
    CustomEvent: dom.CustomEvent,
    matchMedia: () => ({ matches: false, addEventListener() {} }),
    requestAnimationFrame: () => 1,
    cancelAnimationFrame: () => {},
    ResizeObserver: class {
      observe() {}
    },
  });
  Object.defineProperty(dom.HTMLCanvasElement.prototype, "getContext", {
    value: () => null,
  });
  Object.defineProperty(dom.document.querySelector("#arena"), "clientWidth", {
    value: 360,
  });
  Object.defineProperty(dom.document.querySelector("#arena"), "clientHeight", {
    value: 645,
  });
  const { Arcade } = await import("../src/scripts/arcade");
  const game = new Arcade();
  game.start();
  game.motion(16);
  const target = game.targets[0];
  const before = target.el.style.transform;
  game.elapsed = 1000;
  game.motion(16);
  assert.notEqual(before, target.el.style.transform);
  game.held = target;
  const pinned = target.el.style.transform;
  game.elapsed = 2000;
  game.motion(16);
  assert.equal(target.el.style.transform, pinned);
  game.release();
  target.el.focus();
  game.keyboardAim = true;
  game.elapsed = 3000;
  game.motion(16);
  assert.equal(target.el.style.transform, pinned);
  game.rage = 99;
  game.rageBlast();
  assert.equal(game.targets[0].hp, game.targets[0].max);
  game.rage = 100;
  game.rageBlast();
  assert.ok(game.targets.every((t) => t.hp === 0));
  assert.equal(game.rage, 0);
  game.wave = 3;
  game.spawnWave();
  game.rage = 100;
  game.rageBlast();
  assert.equal(game.targets[0].hp, game.targets[0].max);
  assert.equal(game.rage, 100);
  game.container
    .querySelectorAll<HTMLButtonElement>(".boss-shields button")
    .forEach((b) => b.click());
  game.rageBlast();
  assert.ok(game.targets[0].hp < game.targets[0].max);
  assert.equal(game.rage, 0);
  game.wave = 6;
  game.spawnWave();
  game.rage = 100;
  game.rageBlast();
  assert.equal(game.targets[0].hp, game.targets[0].max);
  game.elapsed = game.bossStarted + 2500;
  game.rageBlast();
  assert.ok(game.targets[0].hp < game.targets[0].max);
  game.combo = 7;
  game.lastHit = 0;
  game.elapsed = 5000;
  game.tick(5000);
  assert.equal(game.combo, 1);
  game.togglePause();
  assert.equal(game.rageButton?.disabled, true);
  await dom.happyDOM.close();
});
