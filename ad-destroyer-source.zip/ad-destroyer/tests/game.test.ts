import { test } from "node:test";
import assert from "node:assert/strict";
import { Window } from "happy-dom";
import { readFileSync } from "node:fs";
import {
  damage,
  bossCanTakeDamage,
  videoVulnerable,
  nextCombo,
  scoreFor,
} from "../src/scripts/rules";
test("boss rules, combo expiry, and weapon differences", () => {
  assert.equal(bossCanTakeDamage("cookie", 1, 5000), false);
  assert.equal(bossCanTakeDamage("cookie", 0, 0), true);
  assert.equal(videoVulnerable(2399), false);
  assert.equal(videoVulnerable(2400), true);
  assert.equal(videoVulnerable(4200), false);
  assert.equal(nextCombo(7, 100, 400), 8);
  assert.equal(nextCombo(8, 100, 2400), 1);
  assert.equal(scoreFor(3, true), 3000);
  assert.ok(damage.laser > damage.hammer && damage.hammer > damage.chainsaw);
});
test("touch/pointer attacks, continuous chainsaw, laser cooldown, bosses, pause and completion", async () => {
  const dom = new Window({ url: "http://localhost:4321" });
  dom.document.write(readFileSync("dist/index.html", "utf8"));
  Object.assign(globalThis, {
    window: dom,
    document: dom.document,
    location: dom.location,
    CustomEvent: dom.CustomEvent,
    DOMException: dom.DOMException,
    matchMedia: () => ({ matches: true, addEventListener() {} }),
    requestAnimationFrame: () => 1,
    cancelAnimationFrame: () => {},
    ResizeObserver: class {
      observe() {}
    },
  });
  const arena = dom.document.querySelector("#arena")!;
  Object.defineProperty(arena, "clientWidth", { value: 360 });
  Object.defineProperty(arena, "clientHeight", { value: 565 });
  Object.defineProperty(dom.HTMLCanvasElement.prototype, "getContext", {
    value: () => null,
  });
  const events: string[] = [];
  dom.addEventListener("ad-destroyer:event", (event) =>
    events.push((event as unknown as CustomEvent).detail.name),
  );
  const { Arcade } = await import("../src/scripts/arcade");
  const game = new Arcade();
  game.start();
  assert.equal(game.targets.length, 3);
  assert.equal(game.overlay.hidden, true);
  const touch = new dom.PointerEvent("pointerdown", {
    pointerType: "touch",
    button: 0,
    bubbles: true,
  });
  const first = game.targets[0];
  first.el.dispatchEvent(touch as unknown as Event);
  assert.equal(first.hp, first.max - damage.hammer);
  dom.dispatchEvent(new dom.PointerEvent("pointerup"));
  assert.equal(game.held, null);
  game.elapsed += 200;
  first.el.dispatchEvent(
    new dom.MouseEvent("click", { detail: 0 }) as unknown as Event,
  );
  assert.equal(first.hp, 0);
  assert.equal(first.el.hidden, true);
  assert.ok(game.score > 0);
  game.select("chainsaw");
  const saw = game.targets[1];
  game.elapsed += 200;
  saw.el.dispatchEvent(
    new dom.PointerEvent("pointerdown", {
      pointerType: "touch",
      button: 0,
    }) as unknown as Event,
  );
  const initial = saw.hp;
  game.previous = 1000;
  for (let t = 1080; t < 1600; t += 80) game.tick(t);
  assert.ok(saw.hp < initial);
  dom.dispatchEvent(new dom.PointerEvent("pointercancel"));
  assert.equal(game.held, null);
  game.select("laser");
  const laser = game.targets[2];
  game.elapsed += 700;
  game.attack(laser);
  const hp = laser.hp;
  game.attack(laser);
  assert.equal(laser.hp, hp);
  game.elapsed += 650;
  game.attack(laser);
  assert.equal(laser.hp, 0);
  game.wave = 3;
  game.spawnWave();
  const cookie = game.targets[0];
  game.elapsed += 700;
  game.attack(cookie);
  assert.equal(cookie.hp, cookie.max);
  game.container
    .querySelectorAll<HTMLButtonElement>(".boss-shields button")
    .forEach((b) => b.click());
  assert.equal(game.shields, 0);
  for (let i = 0; i < 3; i++) {
    game.elapsed += 700;
    game.attack(cookie);
  }
  assert.equal(cookie.hp, 0);
  game.wave = 6;
  game.spawnWave();
  const video = game.targets[0];
  game.elapsed += 700;
  game.attack(video);
  assert.equal(video.hp, video.max);
  game.elapsed = game.bossStarted + 2500;
  game.attack(video);
  assert.ok(video.hp < video.max);
  game.elapsed += 700;
  game.attack(video);
  game.elapsed += 700;
  game.attack(video);
  assert.equal(video.hp, 0);
  game.elapsed += 1000;
  game.tick(1700);
  assert.equal(game.running, false);
  assert.match(game.overlay.textContent!, /YOU DELETED THE NOISE/);
  assert.ok(events.includes("game_completed"));
  assert.equal(events.filter((e) => e === "boss_defeated").length, 2);
  game.start();
  assert.equal(game.score, 0);
  assert.equal(game.wave, 1);
  assert.equal(game.targets.length, 3);
  game.togglePause();
  const remaining = game.remaining;
  game.tick(1900);
  assert.equal(game.remaining, remaining);
  game.togglePause();
  assert.equal(game.paused, false);
  game.remaining = 1;
  game.previous = 1900;
  game.tick(1980);
  assert.equal(game.running, false);
  assert.match(game.overlay.textContent!, /TIME’S UP/);
  assert.equal(game.particles.length, 0, "Reduced motion suppresses debris");
  const originalNavigator = Object.getOwnPropertyDescriptor(
    globalThis,
    "navigator",
  );
  try {
    let shared = "";
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        share: async (data: { text: string }) => {
          shared = data.text;
        },
      },
    });
    await game.share();
    assert.match(shared, /AD DESTROYER/);
    let copied = "";
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        clipboard: {
          writeText: async (text: string) => {
            copied = text;
          },
        },
      },
    });
    await game.share();
    assert.match(copied, /http:\/\/localhost:4321\//);
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        clipboard: {
          writeText: async () => {
            throw new Error("denied");
          },
        },
      },
    });
    await game.share();
    assert.ok(game.overlay.querySelector("textarea[readonly]"));
    assert.ok(events.includes("score_shared"));
  } finally {
    if (originalNavigator)
      Object.defineProperty(globalThis, "navigator", originalNavigator);
  }
  await dom.happyDOM.close();
});
test("play through all six waves using game transitions", async () => {
  const dom = new Window({ url: "http://localhost:4321" });
  dom.document.write(readFileSync("dist/index.html", "utf8"));
  Object.assign(globalThis, {
    window: dom,
    document: dom.document,
    location: dom.location,
    CustomEvent: dom.CustomEvent,
    matchMedia: () => ({ matches: true, addEventListener() {} }),
    requestAnimationFrame: () => 1,
    cancelAnimationFrame: () => {},
    ResizeObserver: class {
      observe() {}
    },
  });
  Object.defineProperty(dom.HTMLCanvasElement.prototype, "getContext", {
    value: () => null,
  });
  const { Arcade } = await import("../src/scripts/arcade");
  const game = new Arcade();
  game.start();
  game.select("laser");
  let guard = 0;
  while (game.running && guard++ < 200) {
    if (game.wave === 3)
      game.container
        .querySelectorAll<HTMLButtonElement>(".boss-shields button")
        .forEach((b) => b.click());
    for (const t of game.targets.filter((t) => t.hp > 0)) {
      game.elapsed += 700;
      if (
        t.boss === "video" &&
        !videoVulnerable(game.elapsed - game.bossStarted)
      )
        game.elapsed += 2400;
      game.attack(t);
    }
    if (game.pendingWave) {
      game.elapsed += 700;
      game.tick(guard * 80);
    }
  }
  assert.equal(game.running, false);
  assert.equal(game.wave, 6);
  assert.ok(game.remaining > 0);
  assert.ok(game.score > 2000);
  await dom.happyDOM.close();
});
