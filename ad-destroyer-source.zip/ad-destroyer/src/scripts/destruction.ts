import type { Weapon } from "./rules";
export type Shard = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  spin: number;
  life: number;
  max: number;
  sx: number;
  sy: number;
  sw: number;
  sh: number;
  texture: HTMLCanvasElement;
  burn: boolean;
};
export function stepShard(p: Shard, dt: number, width: number, floor: number) {
  const s = Math.min(Math.max(dt, 0), 40) / 1000;
  p.life -= dt;
  p.vy += 960 * s;
  p.x += p.vx * s;
  p.y += p.vy * s;
  p.angle += p.spin * s;
  if (p.x < 0) {
    p.x = 0;
    p.vx = Math.abs(p.vx) * 0.55;
  }
  if (p.x > width) {
    p.x = width;
    p.vx = -Math.abs(p.vx) * 0.55;
  }
  if (p.y > floor) {
    p.y = floor;
    p.vy = -Math.abs(p.vy) * 0.34;
    p.vx *= 0.72;
    p.spin *= 0.7;
  }
}
type Spark = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
};
type Ring = {
  x: number;
  y: number;
  life: number;
  max: number;
  color: string;
  radius: number;
};
type Label = {
  x: number;
  y: number;
  life: number;
  text: string;
  color: string;
  big: boolean;
};
export class Destruction {
  shards: Shard[] = [];
  sparks: Spark[] = [];
  rings: Ring[] = [];
  labels: Label[] = [];
  width = 1;
  height = 1;
  time = 0;
  pointer = { x: 0, y: 0, visible: false, touch: false };
  weapon: Weapon = "hammer";
  swing = 0;
  beam = 0;
  cutting = false;
  shake = 0;
  reduced = false;
  textures = new Map<string, HTMLCanvasElement>();
  constructor(
    public canvas: HTMLCanvasElement,
    public ctx: CanvasRenderingContext2D | null,
  ) {}
  resize(w: number, h: number) {
    this.width = w;
    this.height = h;
  }
  clear() {
    this.shards = [];
    this.sparks = [];
    this.rings = [];
    this.labels = [];
    this.swing = 0;
    this.beam = 0;
  }
  texture(el: HTMLElement, w: number, h: number) {
    const title = el.querySelector("strong")?.textContent || "FAKE AD";
    const key = title + Math.round(w) + Math.round(h);
    if (this.textures.has(key)) return this.textures.get(key)!;
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    const g = c.getContext("2d");
    if (!g) return c;
    g.fillStyle = el.style.background || "#d8ff3e";
    g.fillRect(0, 0, w, h);
    g.fillStyle = "#00000018";
    g.fillRect(0, 0, w, 25);
    g.fillStyle = "#101114";
    g.font = "9px monospace";
    g.fillText("FICTIONAL GAME AD", 10, 16);
    g.font = `900 ${w < 190 ? 19 : 25}px sans-serif`;
    let y = 54;
    for (const line of [
      title,
      el.querySelector(".subtitle")?.textContent || "",
    ]) {
      let row = "";
      for (const word of line.split(" ")) {
        const next = row ? row + " " + word : word;
        if (g.measureText(next).width > w - 24 && row) {
          g.fillText(row, 12, y);
          y += 25;
          row = word;
        } else row = next;
      }
      g.fillText(row, 12, y);
      y += 25;
    }
    g.fillStyle = "#171922";
    g.fillRect(10, h - 32, w - 20, 22);
    g.fillStyle = "#fff";
    g.font = "bold 9px monospace";
    g.fillText("SMASH THIS FAKE AD", 18, h - 18);
    if (this.textures.size >= 18)
      this.textures.delete(this.textures.keys().next().value!);
    this.textures.set(key, c);
    return c;
  }
  hit(x: number, y: number, color: string, weapon: Weapon, killed: boolean) {
    this.pointer.x = x;
    this.pointer.y = y;
    this.weapon = weapon;
    this.swing = 1;
    if (this.reduced) return;
    this.beam = weapon === "laser" ? 1 : 0;
    this.shake = Math.max(this.shake, killed ? 9 : weapon === "hammer" ? 5 : 1);
    this.rings.push({
      x,
      y,
      life: weapon === "hammer" ? 330 : 220,
      max: weapon === "hammer" ? 330 : 220,
      color: weapon === "laser" ? "#ff55e7" : color,
      radius: killed ? 115 : 65,
    });
    const n = weapon === "chainsaw" ? 12 : killed ? 48 : 22;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = (killed ? 340 : 190) + Math.random() * 240;
      this.sparks.push({
        x,
        y,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v - (weapon === "chainsaw" ? 100 : 50),
        life: 350 + Math.random() * 450,
        max: 800,
        color:
          i % 3 === 0
            ? "#fff"
            : weapon === "chainsaw"
              ? "#ffb743"
              : weapon === "laser"
                ? "#ff55e7"
                : color,
        size: 1 + Math.random() * 3,
      });
    }
    this.sparks = this.sparks.slice(-280);
    this.rings = this.rings.slice(-12);
  }
  shatter(
    el: HTMLElement,
    x: number,
    y: number,
    w: number,
    h: number,
    weapon: Weapon,
  ) {
    if (this.reduced || !this.ctx) return;
    const texture = this.texture(el, w, h);
    const cols = weapon === "laser" ? 3 : 4,
      rows = weapon === "chainsaw" ? 5 : 3;
    for (let row = 0; row < rows; row++)
      for (let col = 0; col < cols; col++) {
        const sw = texture.width / cols,
          sh = texture.height / rows;
        const dx = (col + 0.5) / cols - 0.5,
          dy = (row + 0.5) / rows - 0.5;
        this.shards.push({
          x: x + dx * w,
          y: y + dy * h,
          vx: dx * 550 + (Math.random() - 0.5) * 160,
          vy: dy * 250 - 180 - Math.random() * 160,
          angle: 0,
          spin: (Math.random() - 0.5) * 12,
          life: 1500 + Math.random() * 900,
          max: 2400,
          sx: col * sw,
          sy: row * sh,
          sw,
          sh,
          texture,
          burn: weapon === "laser",
        });
      }
    this.shards = this.shards.slice(-160);
  }
  label(x: number, y: number, text: string, color = "#d8ff3e", big = false) {
    this.labels.push({ x, y, text, color, big, life: 1050 });
    this.labels = this.labels.slice(-16);
  }
  shockwave() {
    if (this.reduced) return;
    this.rings.push({
      x: this.width / 2,
      y: this.height / 2,
      life: 750,
      max: 750,
      color: "#d8ff3e",
      radius: this.width,
    });
    this.shake = 12;
  }
  draw(dt: number) {
    const g = this.ctx;
    if (!g) return;
    this.time += dt;
    this.swing = Math.max(0, this.swing - dt / 260);
    this.beam = Math.max(0, this.beam - dt / 260);
    this.shake = Math.max(0, this.shake - dt / 35);
    g.clearRect(0, 0, this.width, this.height);
    if (!this.reduced) {
      for (const p of this.shards) {
        stepShard(p, dt, this.width, this.height - 9);
        g.save();
        g.translate(p.x, p.y);
        g.rotate(p.angle);
        g.scale(Math.max(0.12, Math.abs(Math.cos(p.angle * 0.65))), 1);
        g.globalAlpha = Math.min(1, p.life / 450);
        g.shadowColor = p.burn ? "#ff43da" : "#000";
        g.shadowBlur = p.burn ? 12 : 4;
        g.drawImage(
          p.texture,
          p.sx,
          p.sy,
          p.sw,
          p.sh,
          -p.sw / 2,
          -p.sh / 2,
          p.sw,
          p.sh,
        );
        g.shadowBlur = 0;
        g.strokeStyle = p.burn ? "#ff43da" : "#ffffff55";
        g.lineWidth = 1;
        g.strokeRect(-p.sw / 2, -p.sh / 2, p.sw, p.sh);
        g.restore();
      }
      this.shards = this.shards.filter((p) => p.life > 0);
      g.save();
      g.globalCompositeOperation = "lighter";
      for (const p of this.sparks) {
        p.life -= dt;
        const s = dt / 1000;
        const ox = p.x,
          oy = p.y;
        p.x += p.vx * s;
        p.y += p.vy * s;
        p.vy += 480 * s;
        g.globalAlpha = Math.max(0, p.life / p.max);
        g.strokeStyle = p.color;
        g.lineWidth = p.size;
        g.beginPath();
        g.moveTo(ox, oy);
        g.lineTo(p.x, p.y);
        g.stroke();
      }
      this.sparks = this.sparks.filter((p) => p.life > 0);
      for (const r of this.rings) {
        r.life -= dt;
        const progress = 1 - r.life / r.max;
        g.globalAlpha = Math.max(0, (1 - progress) * 0.8);
        g.strokeStyle = r.color;
        g.lineWidth = 4 * (1 - progress) + 1;
        g.beginPath();
        g.ellipse(
          r.x,
          r.y,
          Math.max(1, r.radius * progress),
          Math.max(1, r.radius * progress * 0.6),
          0,
          0,
          Math.PI * 2,
        );
        g.stroke();
      }
      this.rings = this.rings.filter((r) => r.life > 0);
      g.restore();
    }
    for (const l of this.labels) {
      l.life -= dt;
      g.save();
      g.globalAlpha = Math.min(1, l.life / 250);
      g.translate(l.x, l.y - (this.reduced ? 0 : (1050 - l.life) * 0.045));
      g.rotate(this.reduced ? 0 : l.big ? -0.07 : 0);
      g.font = `900 ${l.big ? 28 : 20}px monospace`;
      g.textAlign = "center";
      g.lineWidth = 5;
      g.strokeStyle = "#070913";
      g.strokeText(l.text, 0, 0);
      g.fillStyle = l.color;
      g.fillText(l.text, 0, 0);
      g.restore();
    }
    this.labels = this.labels.filter((l) => l.life > 0);
    if (
      !this.reduced &&
      (this.pointer.visible || this.swing > 0 || this.cutting)
    )
      this.drawWeapon(g);
  }
  drawWeapon(g: CanvasRenderingContext2D) {
    const { x, y, touch } = this.pointer;
    if (touch && this.swing === 0 && !this.cutting) return;
    g.save();
    g.translate(x, y);
    g.globalAlpha = this.pointer.visible ? 1 : Math.min(1, this.swing * 3);
    g.shadowColor = "#000";
    g.shadowBlur = 12;
    if (this.weapon === "hammer") {
      g.rotate(-0.55 - Math.sin(this.swing * Math.PI) * 1.2);
      g.translate(8, -10);
      g.fillStyle = "#825332";
      g.fillRect(4, 0, 12, 87);
      g.fillStyle = "#d9954b";
      g.fillRect(6, 4, 4, 72);
      g.fillStyle = "#222837";
      g.fillRect(2, 64, 16, 24);
      g.fillStyle = "#748698";
      g.fillRect(-30, -25, 82, 34);
      g.fillStyle = "#e1eef1";
      g.fillRect(-30, -25, 82, 8);
      g.fillStyle = "#394859";
      g.fillRect(43, -17, 9, 26);
      g.strokeStyle = "#101620";
      g.lineWidth = 3;
      g.strokeRect(-30, -25, 82, 34);
    } else if (this.weapon === "chainsaw") {
      g.rotate(-0.7 + (this.cutting ? Math.sin(this.time * 0.16) * 0.04 : 0));
      g.translate(12, 7);
      g.fillStyle = "#d6dfec";
      g.beginPath();
      g.roundRect(-9, -76, 24, 98, 12);
      g.fill();
      g.strokeStyle = this.cutting ? "#fff" : "#718093";
      g.lineWidth = 5;
      g.setLineDash([5, 4]);
      g.lineDashOffset = -this.time * 0.12;
      g.stroke();
      g.setLineDash([]);
      g.fillStyle = "#ff9e35";
      g.beginPath();
      g.roundRect(-26, 0, 58, 50, 8);
      g.fill();
      g.fillStyle = "#181f2e";
      g.fillRect(-12, 12, 31, 18);
      g.fillStyle = "#ffd079";
      g.fillRect(-23, 3, 52, 8);
      g.strokeStyle = "#8495aa";
      g.lineWidth = 6;
      g.strokeRect(-33, 13, 10, 24);
    } else {
      g.shadowColor = "#ff43da";
      g.shadowBlur = 18;
      g.strokeStyle = "#ff83e9";
      g.lineWidth = 1.5;
      g.beginPath();
      g.arc(0, 0, 17, 0, Math.PI * 2);
      g.moveTo(-25, 0);
      g.lineTo(-10, 0);
      g.moveTo(10, 0);
      g.lineTo(25, 0);
      g.moveTo(0, -25);
      g.lineTo(0, -10);
      g.moveTo(0, 10);
      g.lineTo(0, 25);
      g.stroke();
      g.fillStyle = "#fff";
      g.fillRect(-2, -2, 4, 4);
    }
    g.restore();
    if (this.beam > 0) {
      g.save();
      g.globalAlpha = this.beam;
      g.shadowColor = "#ff43da";
      g.shadowBlur = 22;
      g.strokeStyle = "#ff43da";
      g.lineWidth = 10 * this.beam;
      g.beginPath();
      g.moveTo(this.width * 0.5, this.height + 20);
      g.lineTo(x, y);
      g.stroke();
      g.strokeStyle = "#fff";
      g.lineWidth = 2;
      g.stroke();
      g.restore();
    }
  }
}
