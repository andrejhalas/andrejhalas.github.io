import type { Weapon } from "./rules";
/** All sound is synthesized locally. No assets, network, or autoplay. */
export class Sound {
  context: AudioContext | null = null;
  noise: AudioBuffer | null = null;
  saw: OscillatorNode | null = null;
  sawGain: GainNode | null = null;
  muted = true;
  init() {
    this.context ??= new AudioContext();
    if (this.context.state === "suspended")
      void this.context.resume().catch(() => {});
    return this.context;
  }
  hit(weapon: Weapon, killed = false) {
    if (this.muted) return;
    try {
      const c = this.init(),
        t = c.currentTime;
      const o = c.createOscillator(),
        g = c.createGain();
      o.type = weapon === "laser" ? "sawtooth" : "triangle";
      o.frequency.setValueAtTime(
        weapon === "laser" ? 1600 : weapon === "chainsaw" ? 130 : 140,
        t,
      );
      o.frequency.exponentialRampToValueAtTime(
        weapon === "laser" ? 90 : 35,
        t + 0.18,
      );
      g.gain.setValueAtTime(weapon === "laser" ? 0.045 : 0.13, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
      o.connect(g);
      g.connect(c.destination);
      o.start(t);
      o.stop(t + 0.24);
      if (weapon !== "laser" || killed) {
        this.noise ??= c.createBuffer(1, c.sampleRate * 0.3, c.sampleRate);
        const data = this.noise.getChannelData(0);
        if (!data[0])
          for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
        const n = c.createBufferSource(),
          f = c.createBiquadFilter(),
          ng = c.createGain();
        n.buffer = this.noise;
        f.type = "lowpass";
        f.frequency.value = killed ? 2700 : 900;
        ng.gain.setValueAtTime(killed ? 0.13 : 0.08, t);
        ng.gain.exponentialRampToValueAtTime(0.001, t + (killed ? 0.3 : 0.1));
        n.connect(f);
        f.connect(ng);
        ng.connect(c.destination);
        n.start(t);
        n.stop(t + 0.31);
      }
    } catch {
      this.muted = true;
    }
  }
  loop(on: boolean) {
    if (!on || this.muted) {
      if (this.saw) {
        try {
          this.saw.stop();
        } catch {}
        this.saw = null;
      }
      return;
    }
    if (this.saw) return;
    try {
      const c = this.init();
      this.saw = c.createOscillator();
      this.sawGain = c.createGain();
      this.saw.type = "sawtooth";
      this.saw.frequency.value = 76;
      this.sawGain.gain.value = 0.022;
      this.saw.connect(this.sawGain);
      this.sawGain.connect(c.destination);
      this.saw.start();
    } catch {}
  }
  cue(kind: "wave" | "boss" | "combo" | "rage" | "win") {
    if (this.muted) return;
    try {
      const c = this.init(),
        notes =
          kind === "boss"
            ? [98, 92, 65]
            : kind === "rage"
              ? [130, 260, 520]
              : kind === "win"
                ? [262, 330, 392, 524]
                : [220, 330, 440];
      notes.forEach((f, i) => {
        const o = c.createOscillator(),
          g = c.createGain(),
          t = c.currentTime + i * 0.085;
        o.type = "triangle";
        o.frequency.value = f;
        g.gain.setValueAtTime(0.07, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
        o.connect(g);
        g.connect(c.destination);
        o.start(t);
        o.stop(t + 0.26);
      });
    } catch {}
  }
}
