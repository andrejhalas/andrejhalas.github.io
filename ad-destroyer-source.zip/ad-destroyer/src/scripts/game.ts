const start = document.querySelector<HTMLButtonElement>("#start");
let selected: "hammer" | "chainsaw" | "laser" = "hammer";
let muted = true;
const mute = document.querySelector<HTMLButtonElement>("#mute")!;
const beforeMute = () => {
  muted = !muted;
  mute.setAttribute("aria-pressed", String(muted));
  mute.textContent = muted ? "Sound: off" : "Sound: on";
};
mute.addEventListener("click", beforeMute);
const beforeStart = (event: Event) => {
  const b = event.currentTarget as HTMLButtonElement;
  selected = b.dataset.weapon as typeof selected;
  document
    .querySelectorAll("[data-weapon]")
    .forEach((el) => el.setAttribute("aria-pressed", String(el === b)));
};
document
  .querySelectorAll("[data-weapon]")
  .forEach((el) => el.addEventListener("click", beforeStart));
start?.addEventListener(
  "click",
  async () => {
    start.disabled = true;
    try {
      const { Arcade } = await import("./arcade");
      document
        .querySelectorAll("[data-weapon]")
        .forEach((el) => el.removeEventListener("click", beforeStart));
      const arcade = new Arcade();
      mute.removeEventListener("click", beforeMute);
      arcade.muted = muted;
      arcade.select(selected);
      arcade.start();
    } catch {
      start.disabled = false;
      start.textContent = "RELOAD TO RETRY";
      document.querySelector("#game-status")!.textContent =
        "The game could not load. Reload this page to retry.";
    }
  },
  { once: true },
);
