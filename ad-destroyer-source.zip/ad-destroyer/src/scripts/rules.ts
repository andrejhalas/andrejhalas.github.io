export type Weapon = "hammer" | "chainsaw" | "laser";
export const damage: Record<Weapon, number> = {
  hammer: 34,
  chainsaw: 9,
  laser: 62,
};
export const cooldown: Record<Weapon, number> = {
  hammer: 160,
  chainsaw: 80,
  laser: 650,
};
export const waveCount = (wave: number) =>
  wave === 3 || wave === 6 ? 1 : Math.min(wave + 2, 6);
export function videoVulnerable(elapsed: number) {
  return elapsed % 4200 >= 2400;
}
export function bossCanTakeDamage(
  kind: "cookie" | "video",
  shields: number,
  elapsed: number,
) {
  return kind === "cookie" ? shields === 0 : videoVulnerable(elapsed);
}
export function nextCombo(previous: number, lastHit: number, now: number) {
  return now - lastHit <= 2200 ? Math.min(previous + 1, 8) : 1;
}
export const scoreFor = (combo: number, boss = false) =>
  (boss ? 1000 : 100) * combo;
