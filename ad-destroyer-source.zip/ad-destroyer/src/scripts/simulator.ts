import { track } from "./telemetry";
const start = document.querySelector<HTMLButtonElement>("#sim-start")!;
const simulation = document.querySelector<HTMLElement>("#simulation")!;
const warning = document.querySelector<HTMLElement>("#warning")!;
const info = document.querySelector<HTMLElement>("#tactic-info")!;
const smash = document.querySelector<HTMLButtonElement>("#sim-smash")!;
const explanations: Record<string, string> = {
  urgency:
    "Fake urgency: a countdown pressures you to act. In a scam warning, the timer is not evidence of danger.",
  authority:
    "Borrowed authority: official-sounding names and badges are easy to invent. Verify support through a trusted source you open yourself.",
  claims:
    "Unsupported scan claim: a normal web page cannot inspect all your files or run a complete device scan.",
  payment:
    "The payoff: scammers may seek money, credentials, or remote access. Do not contact support details supplied by a suspicious popup.",
};
start.addEventListener("click", () => {
  simulation.hidden = false;
  start.hidden = true;
  warning.classList.remove("smashed");
  smash.disabled = false;
  smash.textContent = "🔨 Destroy the warning";
  info.textContent =
    "Select a tactic to inspect it. This is a harmless simulation.";
  document
    .querySelector<HTMLButtonElement>(".tactic")!
    .focus({ preventScroll: true });
  track("simulator_started");
});
document.querySelectorAll<HTMLButtonElement>(".tactic").forEach((b) =>
  b.addEventListener("click", () => {
    info.textContent = explanations[b.dataset.tactic!];
  }),
);
document.querySelector("#sim-exit")!.addEventListener("click", () => {
  simulation.hidden = true;
  start.hidden = false;
  start.textContent = "RESTART THE SAFE DEMO ↗";
  start.focus({ preventScroll: true });
});
smash.addEventListener("click", () => {
  warning.classList.add("smashed");
  smash.disabled = true;
  smash.textContent = "Warning destroyed ✓";
  warning.querySelector("h2")!.textContent = "✓ Imaginary threat neutralized.";
  info.textContent =
    "The warning was only a web-page element. In a real situation, use your browser’s controls to close the suspicious tab.";
  document
    .querySelector<HTMLButtonElement>("#sim-exit")!
    .focus({ preventScroll: true });
});
start.addEventListener("click", () => {
  warning.querySelector("h2")!.textContent =
    "⚠ Your toaster has 47 imaginary viruses!";
});
