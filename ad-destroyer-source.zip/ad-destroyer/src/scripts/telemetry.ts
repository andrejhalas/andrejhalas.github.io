export type EventName =
  | "game_start"
  | "weapon_selected"
  | "ad_destroyed"
  | "boss_defeated"
  | "game_completed"
  | "score_shared"
  | "simulator_started"
  | "popup_test_started"
  | "popup_test_completed";
// Local event hook only. No cookies, identifiers, storage or network requests.
export function track(
  name: EventName,
  properties: Record<string, string | number> = {},
) {
  window.dispatchEvent(
    new CustomEvent("ad-destroyer:event", { detail: { name, properties } }),
  );
}
