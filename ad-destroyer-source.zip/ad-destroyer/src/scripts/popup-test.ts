import { sitePath } from "./paths";
import { track } from "./telemetry";
export type PopupOutcome = "allowed" | "likely_blocked" | "inconclusive";
export function attemptPopup(open: () => Window | null): {
  outcome: PopupOutcome;
  window: Window | null;
} {
  try {
    const child = open();
    if (!child || child.closed)
      return { outcome: "likely_blocked", window: null };
    child.opener = null;
    return { outcome: "allowed", window: child };
  } catch {
    return { outcome: "inconclusive", window: null };
  }
}
export function initPopupTest() {
  const direct = document.querySelector<HTMLButtonElement>("#test-direct");
  if (!direct) return;
  const delayed = document.querySelector<HTMLButtonElement>("#test-delayed")!,
    cancel = document.querySelector<HTMLButtonElement>("#test-cancel")!,
    close = document.querySelector<HTMLButtonElement>("#test-close")!,
    result = document.querySelector<HTMLElement>("#test-result")!;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let child: Window | null = null;
  let started = false;
  const closeWindow = () => {
    try {
      child?.close();
    } catch {}
    child = null;
    close.hidden = true;
  };
  const complete = (mode: "direct" | "delayed") => {
    timer = undefined;
    direct.disabled = false;
    delayed.disabled = false;
    cancel.hidden = true;
    const response = attemptPopup(() =>
      window.open(
        sitePath("/popup-test-window/"),
        "_blank",
        "popup,width=420,height=360",
      ),
    );
    child = response.window;
    close.hidden = !child;
    const messages = {
      allowed: `Allowed: a usable window handle was returned for the ${mode} attempt. Look for a new tab or window. This does not mean your popup blocker is disabled.`,
      likely_blocked: `Likely blocked or unavailable: the ${mode} attempt returned no usable open window. Browser settings, extensions, isolation rules, or an in-app browser can cause this. This is not a definitive security result.`,
      inconclusive:
        "Inconclusive: the browser prevented this test from inspecting or opening a window. Try your normal browser and review its permissions.",
    };
    result.textContent = messages[response.outcome];
    track("popup_test_completed", { mode, outcome: response.outcome });
    started = false;
  };
  const stop = () => {
    if (timer !== undefined) clearTimeout(timer);
    timer = undefined;
    direct.disabled = false;
    delayed.disabled = false;
    cancel.hidden = true;
    if (started) {
      result.textContent = "Delayed test canceled. No window was opened.";
      track("popup_test_completed", { mode: "delayed", outcome: "canceled" });
    }
    started = false;
  };
  direct.addEventListener("click", () => {
    stop();
    closeWindow();
    track("popup_test_started", { mode: "direct" });
    complete("direct");
  });
  delayed.addEventListener("click", () => {
    stop();
    closeWindow();
    started = true;
    track("popup_test_started", { mode: "delayed" });
    direct.disabled = true;
    delayed.disabled = true;
    cancel.hidden = false;
    result.textContent =
      "Delayed test scheduled. One same-site window will be attempted in 6 seconds. Keep this page visible or cancel.";
    timer = setTimeout(() => complete("delayed"), 6000);
  });
  cancel.addEventListener("click", stop);
  close.addEventListener("click", closeWindow);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden && timer !== undefined) stop();
  });
  window.addEventListener("pagehide", () => {
    stop();
    closeWindow();
  });
}
if (typeof document !== "undefined") initPopupTest();
