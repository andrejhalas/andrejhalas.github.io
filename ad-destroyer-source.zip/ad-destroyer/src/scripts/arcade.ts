import { sitePath } from "./paths";
import { track } from "./telemetry";
import {
  damage,
  cooldown,
  waveCount,
  nextCombo,
  scoreFor,
  bossCanTakeDamage,
  videoVulnerable,
  type Weapon,
} from "./rules";
type Target = {
  id: number;
  hp: number;
  max: number;
  el: HTMLButtonElement;
  boss?: "cookie" | "video";
};
type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
};
const fictionalAds = [
  [
    "#ff83b5",
    "✦",
    "HOT SINGLES",
    "In your spreadsheet.",
    "Meet 47 lonely cells today.",
    "OPEN THE CHAOS",
  ],
  [
    "#d8ff3e",
    "↗",
    "GET RICH",
    "By doing nothing!",
    "Results may include doing nothing.",
    "CLAIM NOTHING",
  ],
  [
    "#baa5ff",
    "☁",
    "DOWNLOAD",
    "More RAM. Somehow.",
    "Cloud-flavored imaginary memory.",
    "INSTALL VIBES",
  ],
  [
    "#ffba71",
    "★",
    "YOU WON!",
    "A new popup.",
    "Congratulations on existing online.",
    "COLLECT YOUR POPUP",
  ],
  [
    "#8be1e4",
    "◉",
    "ONE WEIRD TRICK",
    "Browsers hate it.",
    "It is closing this fictional ad.",
    "BE WEIRDER",
  ],
  [
    "#e1c9f4",
    "⌛",
    "LAST CHANCE",
    "Again. And again.",
    "This sale ends whenever we say so.",
    "PANIC SHOP",
  ],
];
export class Arcade {
  arena = document.querySelector<HTMLElement>("#arena")!;
  container = document.querySelector<HTMLElement>("#targets")!;
  overlay = document.querySelector<HTMLElement>("#game-overlay")!;
  canvas = document.querySelector<HTMLCanvasElement>("#particles")!;
  ctx = this.canvas.getContext("2d");
  status = document.querySelector<HTMLElement>("#game-status")!;
  targets: Target[] = [];
  particles: Particle[] = [];
  weapon: Weapon = "hammer";
  score = 0;
  combo = 1;
  wave = 1;
  remaining = 120000;
  elapsed = 0;
  lastHit = -Infinity;
  lastAttack = -Infinity;
  running = false;
  paused = false;
  muted = true;
  held: Target | null = null;
  frame = 0;
  previous = 0;
  pendingWave = 0;
  transitionAt = 0;
  shields = 0;
  bossPhase = "";
  bossStarted = 0;
  reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  audio: AudioContext | null = null;
  constructor() {
    document.querySelector<HTMLButtonElement>("#restart")!.disabled = false;
    document
      .querySelectorAll<HTMLButtonElement>("[data-weapon]")
      .forEach((b) =>
        b.addEventListener("click", () =>
          this.select(b.dataset.weapon as Weapon),
        ),
      );
    document
      .querySelector("#restart")!
      .addEventListener("click", () => this.start());
    document
      .querySelector("#pause")!
      .addEventListener("click", () => this.togglePause());
    document.querySelector("#mute")!.addEventListener("click", () => {
      this.muted = !this.muted;
      const b = document.querySelector("#mute")!;
      b.setAttribute("aria-pressed", String(this.muted));
      b.textContent = this.muted ? "Sound: off" : "Sound: on";
      if (!this.muted) this.sound(220, 0.06);
    });
    window.addEventListener("pointerup", () => this.release());
    window.addEventListener("pointercancel", () => this.release());
    window.addEventListener("blur", () => this.release());
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && this.running && !this.paused) this.togglePause();
    });
    document.addEventListener("keydown", (e) => {
      if (
        (e.target as HTMLElement)?.matches("input,textarea,select") ||
        e.ctrlKey ||
        e.metaKey ||
        e.altKey
      )
        return;
      if (["1", "2", "3"].includes(e.key)) {
        e.preventDefault();
        this.select(
          (["hammer", "chainsaw", "laser"] as Weapon[])[Number(e.key) - 1],
        );
      }
      if (e.key === "Escape" && this.running) {
        e.preventDefault();
        this.togglePause();
      }
    });
    new ResizeObserver(() => this.resize()).observe(this.arena);
    matchMedia("(prefers-reduced-motion: reduce)").addEventListener(
      "change",
      (e) => {
        this.reduced = e.matches;
        this.particles = [];
      },
    );
  }
  select(weapon: Weapon) {
    this.release();
    this.weapon = weapon;
    document
      .querySelectorAll<HTMLButtonElement>("[data-weapon]")
      .forEach((b) =>
        b.setAttribute("aria-pressed", String(b.dataset.weapon === weapon)),
      );
    track("weapon_selected", { weapon });
    this.status.textContent =
      weapon === "chainsaw"
        ? "Hold a fake ad to shred it. Keyboard: Enter repeatedly cuts."
        : weapon === "laser"
          ? "Precision laser ready. Allow a short cooldown between shots."
          : "Tap a fake ad to smash. Keyboard: Tab to a target, then Enter.";
  }
  resize() {
    const r = this.arena.getBoundingClientRect();
    const d = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = r.width * d;
    this.canvas.height = r.height * d;
    this.ctx?.setTransform(d, 0, 0, d, 0, 0);
    this.place();
  }
  place() {
    const narrow = this.arena.clientWidth < 600;
    const cols = this.arena.clientWidth < 760 ? 2 : 3;
    const stepX = this.arena.clientWidth / cols;
    const stepY = narrow ? 175 : 182;
    this.targets.forEach((t, i) => {
      if (t.boss) return;
      t.el.style.width = (narrow ? this.arena.clientWidth * 0.45 : 225) + "px";
      t.el.style.left = `${stepX * (i % cols) + (stepX - (narrow ? this.arena.clientWidth * 0.45 : 225)) / 2}px`;
      t.el.style.top = `${18 + Math.floor(i / cols) * stepY}px`;
    });
  }
  start() {
    cancelAnimationFrame(this.frame);
    this.release();
    this.targets = [];
    this.container.replaceChildren();
    this.particles = [];
    this.score = 0;
    this.combo = 1;
    this.wave = 1;
    this.remaining = 120000;
    this.elapsed = 0;
    this.lastHit = -Infinity;
    this.lastAttack = -Infinity;
    this.pendingWave = 0;
    this.previous = 0;
    this.running = true;
    this.paused = false;
    this.overlay.hidden = true;
    document.querySelector<HTMLButtonElement>("#pause")!.disabled = false;
    document.querySelector("#pause")!.textContent = "Pause";
    track("game_start");
    this.spawnWave();
    this.updateHud();
    this.frame = requestAnimationFrame((t) => this.tick(t));
  }
  spawnWave() {
    this.container.replaceChildren();
    this.targets = [];
    this.pendingWave = 0;
    this.bossPhase = "";
    this.bossStarted = this.elapsed;
    if (this.wave === 3 || this.wave === 6) {
      const cookie = this.wave === 3;
      this.shields = cookie ? 3 : 0;
      const panel = document.createElement("div");
      panel.className = "boss-panel";
      const t = this.makeTarget(
        cookie ? "Cookie Consent Monster" : "Unskippable Video Ad",
        cookie
          ? "I need your cookies. And your soul."
          : "This ad could have been an email.",
        cookie ? "#b9a0ff" : "#ffba71",
        160,
        cookie ? "cookie" : "video",
      );
      panel.append(t.el);
      if (cookie) {
        const shields = document.createElement("div");
        shields.className = "boss-shields";
        for (let i = 0; i < 3; i++) {
          const b = document.createElement("button");
          b.textContent = ["Tracking", "Partners", "Personalization"][i];
          b.setAttribute("aria-label", `Break ${b.textContent} shield`);
          b.addEventListener("click", () => {
            if (!this.running || this.paused) return;
            b.disabled = true;
            b.textContent = "Broken ✓";
            this.shields--;
            this.sound(340, 0.07);
            this.status.textContent = this.shields
              ? `${this.shields} cookie shields left. Break them before attacking the monster.`
              : "All shields broken. Attack the Cookie Consent Monster!";
          });
          shields.append(b);
        }
        panel.append(shields);
      }
      const phase = document.createElement("div");
      phase.id = "boss-phase";
      phase.className = "boss-phase";
      panel.append(phase);
      const hint = document.createElement("p");
      hint.className = "boss-hint";
      hint.textContent = cookie
        ? "Break the 3 cookie shields. Then smash the monster."
        : "Damage works only during the green “SKIP WINDOW”.";
      panel.append(hint);
      this.container.append(panel);
      this.status.textContent = cookie
        ? "BOSS: Break all three cookie shields, then attack."
        : "BOSS: Wait for the green skip window, then attack.";
    } else {
      for (let i = 0; i < waveCount(this.wave); i++) {
        const ad = fictionalAds[(i + this.wave - 1) % fictionalAds.length];
        const t = this.makeTarget(ad[2], ad[3], ad[0], 55 + this.wave * 7);
        t.el.querySelector(".target-icon")!.textContent = ad[1];
        t.el.querySelector("small")!.textContent = ad[4];
        t.el.querySelector(".fake-cta")!.textContent = ad[5];
        this.container.append(t.el);
      }
      this.status.textContent = `Wave ${this.wave}. Destroy every fictional ad to move on.`;
    }
    this.place();
  }
  makeTarget(
    title: string,
    subtitle: string,
    color: string,
    hp: number,
    boss?: "cookie" | "video",
  ) {
    const el = document.createElement("button");
    el.className = `target${boss ? " boss" : ""}`;
    el.style.background = color;
    el.setAttribute("aria-label", `Attack fictional ${title}`);
    el.innerHTML =
      '<span class="target-head"><span>FICTIONAL GAME AD</span><span aria-hidden="true">×</span></span><div class="target-body"><span class="target-icon" aria-hidden="true">' +
      (boss === "cookie" ? "🍪" : boss ? "▶" : "✦") +
      '</span><strong></strong><strong class="subtitle"></strong><small></small><span class="fake-cta" aria-hidden="true">SMASH THIS FAKE AD</span></div><progress aria-label="Target health"></progress>';
    el.querySelector("strong")!.textContent = title;
    el.querySelector(".subtitle")!.textContent = subtitle;
    const p = el.querySelector("progress")!;
    p.max = hp;
    p.value = hp;
    const target: Target = { id: this.targets.length, hp, max: hp, el, boss };
    this.targets.push(target);
    el.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || !this.running || this.paused) return;
      e.preventDefault();
      this.release();
      el.focus({ preventScroll: true });
      el.setPointerCapture?.(e.pointerId);
      this.held = target;
      this.attack(target);
      if (this.weapon === "chainsaw") el.classList.add("cutting");
    });
    el.addEventListener("lostpointercapture", () => this.release());
    el.addEventListener("click", (e) => {
      if (e.detail === 0) this.attack(target);
    });
    return target;
  }
  release() {
    this.held?.el.classList.remove("cutting");
    this.held = null;
  }
  attack(t: Target) {
    if (
      !this.running ||
      this.paused ||
      t.hp <= 0 ||
      this.elapsed - this.lastAttack < cooldown[this.weapon]
    )
      return;
    this.lastAttack = this.elapsed;
    if (
      t.boss &&
      !bossCanTakeDamage(t.boss, this.shields, this.elapsed - this.bossStarted)
    ) {
      this.status.textContent =
        t.boss === "cookie"
          ? "Shielded! Break Tracking, Partners, and Personalization first."
          : "Unskippable means unskippable. Wait for the green window.";
      this.sound(85, 0.08);
      return;
    }
    const a = this.arena.getBoundingClientRect(),
      r = t.el.getBoundingClientRect();
    const x = r.left - a.left + r.width / 2,
      y = r.top - a.top + r.height / 2;
    this.sound(
      this.weapon === "laser" ? 700 : this.weapon === "chainsaw" ? 100 : 160,
      0.06,
    );
    if (this.weapon === "chainsaw" && !this.reduced)
      try {
        navigator.vibrate?.(12);
      } catch {}
    t.hp = Math.max(0, t.hp - damage[this.weapon]);
    t.el.querySelector("progress")!.value = t.hp;
    t.el.classList.add("damaged");
    if (this.weapon === "laser") {
      t.el.classList.add("burnt");
      if (!this.reduced) {
        const beam = document.createElement("span");
        beam.className = "laser-beam";
        const dx = x - a.width / 2,
          dy = a.height - y;
        beam.style.height = `${Math.hypot(dx, dy)}px`;
        beam.style.transform = `rotate(${Math.atan2(dx, dy)}rad)`;
        this.arena.append(beam);
        setTimeout(() => beam.remove(), 250);
      }
    }
    this.burst(x, y, t.el.style.background, t.hp === 0 ? 22 : 7);
    const impact = document.querySelector<HTMLElement>("#impact")!;
    impact.textContent =
      this.weapon === "hammer" ? "🔨" : this.weapon === "chainsaw" ? "⚙" : "✧";
    impact.style.left = x + "px";
    impact.style.top = y + "px";
    impact.classList.remove("strike");
    void impact.offsetWidth;
    impact.classList.add("strike");
    setTimeout(() => impact.classList.remove("strike"), 260);
    if (!this.reduced) {
      this.arena.classList.remove("shake");
      void this.arena.offsetWidth;
      this.arena.classList.add("shake");
    }
    if (t.hp === 0) {
      const hadFocus = document.activeElement === t.el;
      this.combo = nextCombo(this.combo, this.lastHit, this.elapsed);
      this.lastHit = this.elapsed;
      this.score += scoreFor(this.combo, !!t.boss);
      t.el.hidden = true;
      if (this.held === t) this.release();
      track(
        t.boss ? "boss_defeated" : "ad_destroyed",
        t.boss ? { boss: t.boss } : { weapon: this.weapon },
      );
      this.status.textContent = t.boss
        ? "BOSS DEFEATED. Your browser can breathe again."
        : `DESTROYED. ${this.combo > 1 ? `×${this.combo} combo!` : "Keep going."}`;
      if (this.targets.every((x) => x.hp === 0)) {
        this.pendingWave = this.wave + 1;
        this.transitionAt = this.elapsed + 600;
        this.container.querySelector(".boss-shields")?.remove();
        this.container.querySelector("#boss-phase")?.remove();
      }
      const next = this.targets.find((x) => x.hp > 0);
      if (hadFocus) next?.el.focus({ preventScroll: true });
    }
    this.updateHud();
  }
  burst(x: number, y: number, color: string, n: number) {
    if (this.reduced || !this.ctx) return;
    for (let i = 0; i < n; i++)
      this.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 7,
        vy: -Math.random() * 6,
        life: 600,
        color,
        size: 3 + Math.random() * 7,
      });
    this.particles = this.particles.slice(-150);
  }
  sound(freq: number, duration: number) {
    if (this.muted) return;
    try {
      this.audio ??= new AudioContext();
      if (this.audio.state === "suspended")
        void this.audio.resume().catch(() => {});
      const o = this.audio.createOscillator(),
        g = this.audio.createGain();
      o.type = this.weapon === "chainsaw" ? "sawtooth" : "triangle";
      o.frequency.setValueAtTime(freq, this.audio.currentTime);
      o.frequency.exponentialRampToValueAtTime(
        40,
        this.audio.currentTime + duration,
      );
      g.gain.setValueAtTime(0.07, this.audio.currentTime);
      g.gain.exponentialRampToValueAtTime(
        0.001,
        this.audio.currentTime + duration,
      );
      o.connect(g);
      g.connect(this.audio.destination);
      o.start();
      o.stop(this.audio.currentTime + duration);
    } catch {
      this.muted = true;
      document.querySelector("#mute")!.textContent = "Sound unavailable";
      document.querySelector("#mute")!.setAttribute("aria-pressed", "true");
    }
  }
  tick(timestamp: number) {
    if (!this.running || this.paused) return;
    const delta = this.previous ? Math.min(timestamp - this.previous, 80) : 0;
    this.previous = timestamp;
    this.remaining = Math.max(0, this.remaining - delta);
    this.elapsed += delta;
    if (this.held && this.weapon === "chainsaw") this.attack(this.held);
    if (this.remaining <= 0) {
      this.finish(false);
      return;
    }
    if (this.pendingWave && this.elapsed >= this.transitionAt) {
      if (this.pendingWave > 6) {
        this.finish(true);
        return;
      }
      this.wave = this.pendingWave;
      this.spawnWave();
    }
    const phase = document.querySelector("#boss-phase");
    if (phase) {
      const open =
        this.wave === 3
          ? this.shields === 0
          : videoVulnerable(this.elapsed - this.bossStarted);
      const label = open
        ? "OPEN — SMASH NOW!"
        : this.wave === 3
          ? `${this.shields} SHIELDS REMAIN`
          : "UNSKIPPABLE — WAIT FOR GREEN";
      if (label !== this.bossPhase) {
        phase.textContent = label;
        phase.classList.toggle("shielded", !open);
        this.bossPhase = label;
      }
    }
    if (this.ctx) {
      this.ctx.clearRect(0, 0, this.arena.clientWidth, this.arena.clientHeight);
      for (const p of this.particles) {
        p.life -= delta;
        p.x += (p.vx * delta) / 16;
        p.y += (p.vy * delta) / 16;
        p.vy += (0.15 * delta) / 16;
        this.ctx.globalAlpha = Math.max(0, p.life / 600);
        this.ctx.fillStyle = p.color;
        this.ctx.fillRect(p.x, p.y, p.size, p.size);
      }
      this.ctx.globalAlpha = 1;
      this.particles = this.particles.filter((p) => p.life > 0);
    }
    this.updateHud();
    this.frame = requestAnimationFrame((t) => this.tick(t));
  }
  updateHud() {
    document.querySelector("#score")!.textContent = String(this.score).padStart(
      5,
      "0",
    );
    document.querySelector("#combo")!.textContent = `×${this.combo}`;
    document.querySelector("#wave")!.textContent = `${this.wave} / 6`;
    const time = document.querySelector("#time")!;
    const seconds = String(Math.ceil(this.remaining / 1000));
    if (time.textContent !== seconds) time.textContent = seconds;
  }
  togglePause() {
    if (!this.running) return;
    this.release();
    this.paused = !this.paused;
    const button = document.querySelector("#pause")!;
    button.textContent = this.paused ? "Resume" : "Pause";
    if (this.paused) {
      cancelAnimationFrame(this.frame);
      this.status.textContent = "Paused. Press Resume or Escape to continue.";
    } else {
      this.previous = 0;
      this.frame = requestAnimationFrame((t) => this.tick(t));
      this.status.textContent = "Back to demolition.";
    }
  }
  finish(won: boolean) {
    this.running = false;
    this.release();
    cancelAnimationFrame(this.frame);
    document.querySelector<HTMLButtonElement>("#pause")!.disabled = true;
    track("game_completed", {
      score: this.score,
      result: won ? "won" : "time_up",
    });
    this.overlay.hidden = false;
    this.overlay.innerHTML = `<span class="eyebrow">${won ? "INTERNET REPAIRED. FOR NOW." : "THE INTERNET FOUGHT BACK."}</span><h3>${won ? "YOU DELETED THE NOISE." : "TIME’S UP. RAGE ON."}</h3><p>Final score <strong class="lime">${this.score.toLocaleString()}</strong> · Wave ${this.wave} / 6</p><div class="demo-actions"><button class="primary" id="play-again">SMASH AGAIN ↻</button><button id="share">Share score ↗</button></div><p class="small" id="share-status" role="status"></p>`;
    this.overlay
      .querySelector("#play-again")!
      .addEventListener("click", () => this.start());
    this.overlay
      .querySelector("#share")!
      .addEventListener("click", () => void this.share());
    this.overlay
      .querySelector<HTMLButtonElement>("#play-again")!
      .focus({ preventScroll: true });
    this.status.textContent = won
      ? "Completed all six waves. Both bosses defeated."
      : "Time is up. Try another weapon and restart.";
  }
  async share() {
    const text = `I scored ${this.score.toLocaleString()} in AD DESTROYER. The internet is broken. Fix it with a hammer.`;
    const url = new URL(sitePath("/"), location.href).href;
    const status = this.overlay.querySelector("#share-status")!;
    try {
      if (navigator.share) {
        await navigator.share({ title: "AD DESTROYER", text, url });
        status.textContent = "Score shared.";
        track("score_shared", { method: "web_share" });
      } else {
        await navigator.clipboard.writeText(`${text} ${url}`);
        status.textContent = "Score copied. Paste it anywhere.";
        track("score_shared", { method: "clipboard" });
      }
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") {
        status.textContent = "Share canceled.";
        return;
      }
      status.textContent = "Copy your score from the box below.";
      if (!this.overlay.querySelector("textarea")) {
        const field = document.createElement("textarea");
        field.className = "copy-area";
        field.readOnly = true;
        field.setAttribute("aria-label", "Score text to copy");
        field.value = `${text} ${url}`;
        this.overlay.append(field);
        field.focus();
        field.select();
      }
    }
  }
}
