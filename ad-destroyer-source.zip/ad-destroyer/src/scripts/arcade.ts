import { Destruction } from "./destruction";
import { Sound } from "./audio";
import { targetMotion } from "./rules";
import { sitePath } from "./paths";
import { track } from "./telemetry";
import {
  damage,
  cooldown,
  waveCount,
  nextCombo,
  scoreFor,
  bossCanTakeDamage,
  videoVulnerable,
  type Weapon,
} from "./rules";
type Target = {
  id: number;
  hp: number;
  max: number;
  el: HTMLButtonElement;
  boss?: "cookie" | "video";
  x: number;
  y: number;
  kick: number;
  born: number;
};
const fictionalAds = [
  [
    "#ff83b5",
    "✦",
    "HOT SINGLES",
    "In your spreadsheet.",
    "Meet 47 lonely cells today.",
    "OPEN THE CHAOS",
  ],
  [
    "#d8ff3e",
    "↗",
    "GET RICH",
    "By doing nothing!",
    "Results may include doing nothing.",
    "CLAIM NOTHING",
  ],
  [
    "#baa5ff",
    "☁",
    "DOWNLOAD",
    "More RAM. Somehow.",
    "Cloud-flavored imaginary memory.",
    "INSTALL VIBES",
  ],
  [
    "#ffba71",
    "★",
    "YOU WON!",
    "A new popup.",
    "Congratulations on existing online.",
    "COLLECT YOUR POPUP",
  ],
  [
    "#8be1e4",
    "◉",
    "ONE WEIRD TRICK",
    "Browsers hate it.",
    "It is closing this fictional ad.",
    "BE WEIRDER",
  ],
  [
    "#e1c9f4",
    "⌛",
    "LAST CHANCE",
    "Again. And again.",
    "This sale ends whenever we say so.",
    "PANIC SHOP",
  ],
];
export class Arcade {
  arena = document.querySelector<HTMLElement>("#arena")!;
  container = document.querySelector<HTMLElement>("#targets")!;
  overlay = document.querySelector<HTMLElement>("#game-overlay")!;
  canvas = document.querySelector<HTMLCanvasElement>("#particles")!;
  ctx = this.canvas.getContext("2d");
  status = document.querySelector<HTMLElement>("#game-status")!;
  fx = new Destruction(this.canvas, this.ctx);
  sfx = new Sound();
  rage = 0;
  kills = 0;
  bestCombo = 1;
  shots = 0;
  keyboardAim = false;
  announceUntil = 0;
  comboWidth = -1;
  renderedScore = -1;
  stage = document.querySelector<HTMLElement>("#wave-announcement");
  rageButton = document.querySelector<HTMLButtonElement>("#rage-blast");
  focusButton = document.querySelector<HTMLButtonElement>("#focus-game");

  targets: Target[] = [];
  particles: unknown[] = [];
  weapon: Weapon = "hammer";
  score = 0;
  combo = 1;
  wave = 1;
  remaining = 120000;
  elapsed = 0;
  lastHit = -Infinity;
  lastAttack = -Infinity;
  running = false;
  paused = false;
  muted = true;
  held: Target | null = null;
  frame = 0;
  previous = 0;
  pendingWave = 0;
  transitionAt = 0;
  shields = 0;
  bossPhase = "";
  bossStarted = 0;
  reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;

  constructor() {
    this.fx.reduced = this.reduced;
    this.rageButton?.addEventListener("click", () => this.rageBlast());
    if (this.focusButton) this.focusButton.disabled = false;
    this.focusButton?.addEventListener("click", () => {
      document.querySelector("#arcade")?.classList.toggle("focus-mode");
      this.focusButton!.setAttribute(
        "aria-pressed",
        String(
          document.querySelector("#arcade")?.classList.contains("focus-mode"),
        ),
      );
      this.resize();
    });
    this.arena.addEventListener("pointermove", (e) => {
      const r = this.arena.getBoundingClientRect();
      this.fx.pointer = {
        x: e.clientX - r.left,
        y: e.clientY - r.top,
        visible: e.pointerType !== "touch",
        touch: e.pointerType === "touch",
      };
    });
    this.arena.addEventListener("pointerleave", () => {
      this.fx.pointer.visible = false;
    });
    document.querySelector<HTMLButtonElement>("#restart")!.disabled = false;
    document
      .querySelectorAll<HTMLButtonElement>("[data-weapon]")
      .forEach((b) =>
        b.addEventListener("click", () =>
          this.select(b.dataset.weapon as Weapon),
        ),
      );
    document
      .querySelector("#restart")!
      .addEventListener("click", () => this.start());
    document
      .querySelector("#pause")!
      .addEventListener("click", () => this.togglePause());
    document.querySelector("#mute")!.addEventListener("click", () => {
      this.muted = !this.muted;
      const b = document.querySelector("#mute")!;
      b.setAttribute("aria-pressed", String(this.muted));
      b.textContent = this.muted ? "Sound: off" : "Sound: on";
      this.sfx.muted = this.muted;
      if (this.muted) this.sfx.loop(false);
      else this.sfx.cue("wave");
    });
    window.addEventListener("pointerup", () => this.release());
    window.addEventListener("pointercancel", () => this.release());
    window.addEventListener("blur", () => this.release());
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && this.running && !this.paused) this.togglePause();
    });
    document.addEventListener("keydown", (e) => {
      if (
        (e.target as HTMLElement)?.matches("input,textarea,select") ||
        e.ctrlKey ||
        e.metaKey ||
        e.altKey
      )
        return;
      if (e.key === "Tab") this.keyboardAim = true;
      if (e.key.toLowerCase() === "r" && this.running) {
        e.preventDefault();
        this.rageBlast();
      }
      if (["1", "2", "3"].includes(e.key)) {
        e.preventDefault();
        this.select(
          (["hammer", "chainsaw", "laser"] as Weapon[])[Number(e.key) - 1],
        );
      }
      if (e.key === "Escape" && this.running) {
        e.preventDefault();
        this.togglePause();
      }
    });
    new ResizeObserver(() => this.resize()).observe(this.arena);
    matchMedia("(prefers-reduced-motion: reduce)").addEventListener(
      "change",
      (e) => {
        this.reduced = e.matches;
        this.particles = [];
        this.fx.reduced = e.matches;
        this.fx.clear();
      },
    );
  }
  select(weapon: Weapon) {
    this.release();
    this.weapon = weapon;
    this.fx.weapon = weapon;
    this.arena.dataset.weapon = weapon;
    document
      .querySelectorAll<HTMLButtonElement>("[data-weapon]")
      .forEach((b) =>
        b.setAttribute("aria-pressed", String(b.dataset.weapon === weapon)),
      );
    track("weapon_selected", { weapon });
    this.status.textContent =
      weapon === "chainsaw"
        ? "Hold a fake ad to shred it. Keyboard: Enter repeatedly cuts."
        : weapon === "laser"
          ? "Precision laser ready. Allow a short cooldown between shots."
          : "Tap a fake ad to smash. Keyboard: Tab to a target, then Enter.";
  }
  resize() {
    const r = this.arena.getBoundingClientRect();
    const d = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = r.width * d;
    this.canvas.height = r.height * d;
    this.ctx?.setTransform(d, 0, 0, d, 0, 0);
    this.fx.resize(r.width, r.height);
    this.place();
  }
  place() {
    const width = this.arena.clientWidth;
    const narrow = width < 600,
      cols = width < 760 ? 2 : 3;
    const cardWidth = narrow ? width * 0.43 : Math.min(244, width / cols - 48);
    const rows = Math.ceil(this.targets.filter((t) => !t.boss).length / cols);
    this.arena.classList.toggle(
      "compact",
      narrow && this.arena.clientHeight < 590 && rows >= 3,
    );
    const stepY = Math.min(
      narrow ? 198 : 232,
      (this.arena.clientHeight - 38) / Math.max(rows, 1),
    );
    this.targets.forEach((t, i) => {
      if (t.boss) return;
      t.el.style.width = cardWidth + "px";
      t.x = (width / cols) * (i % cols) + (width / cols - cardWidth) / 2;
      t.y = 34 + Math.floor(i / cols) * stepY;
      t.el.style.left = t.x + "px";
      t.el.style.top = t.y + "px";
    });
  }

  start() {
    cancelAnimationFrame(this.frame);
    this.release();
    this.targets = [];
    this.container.replaceChildren();
    this.particles = [];
    this.fx.clear();
    this.rage = 0;
    this.kills = 0;
    this.bestCombo = 1;
    this.shots = 0;
    this.renderedScore = -1;
    this.sfx.muted = this.muted;
    this.resize();
    this.score = 0;
    this.combo = 1;
    this.wave = 1;
    this.remaining = 120000;
    this.elapsed = 0;
    this.lastHit = -Infinity;
    this.lastAttack = -Infinity;
    this.pendingWave = 0;
    this.previous = 0;
    this.running = true;
    this.paused = false;
    this.overlay.hidden = true;
    document.querySelector<HTMLButtonElement>("#pause")!.disabled = false;
    document.querySelector("#pause")!.textContent = "Pause";
    track("game_start");
    this.spawnWave();
    this.updateHud();
    this.frame = requestAnimationFrame((t) => this.tick(t));
  }
  spawnWave() {
    this.container.replaceChildren();
    this.targets = [];
    this.pendingWave = 0;
    this.bossPhase = "";
    this.arena.classList.remove("boss-open");
    this.arena.classList.toggle("crowded", this.wave === 4 || this.wave === 5);
    this.bossStarted = this.elapsed;
    this.announce(
      this.wave === 3
        ? "COOKIE APOCALYPSE"
        : this.wave === 6
          ? "FINAL BOSS"
          : `WAVE 0${this.wave}`,
      this.wave === 3 || this.wave === 6,
    );
    this.sfx.cue(this.wave === 3 || this.wave === 6 ? "boss" : "wave");
    if (this.wave === 3 || this.wave === 6) {
      const cookie = this.wave === 3;
      this.shields = cookie ? 3 : 0;
      const panel = document.createElement("div");
      panel.className =
        "boss-panel " + (cookie ? "cookie-monster" : "video-monster");
      const t = this.makeTarget(
        cookie ? "Cookie Consent Monster" : "Unskippable Video Ad",
        cookie
          ? "I need your cookies. And your soul."
          : "This ad could have been an email.",
        cookie ? "#b9a0ff" : "#ffba71",
        160,
        cookie ? "cookie" : "video",
      );
      panel.append(t.el);
      if (cookie) {
        const shields = document.createElement("div");
        shields.className = "boss-shields";
        for (let i = 0; i < 3; i++) {
          const b = document.createElement("button");
          b.textContent = ["Tracking", "Partners", "Personalization"][i];
          b.setAttribute("aria-label", `Break ${b.textContent} shield`);
          b.addEventListener("click", () => {
            if (!this.running || this.paused) return;
            b.disabled = true;
            b.textContent = "Broken ✓";
            this.shields--;
            this.sfx.cue("combo");
            const a = this.arena.getBoundingClientRect(),
              r = b.getBoundingClientRect();
            this.fx.hit(
              r.left - a.left + r.width / 2,
              r.top - a.top + r.height / 2,
              "#b9a0ff",
              "hammer",
              true,
            );
            this.fx.label(
              r.left - a.left + r.width / 2,
              r.top - a.top,
              "SHIELD BROKEN",
              "#b9a0ff",
            );
            this.status.textContent = this.shields
              ? `${this.shields} cookie shields left. Break them before attacking the monster.`
              : "All shields broken. Attack the Cookie Consent Monster!";
          });
          shields.append(b);
        }
        panel.append(shields);
      }
      const phase = document.createElement("div");
      phase.id = "boss-phase";
      phase.className = "boss-phase";
      panel.append(phase);
      const art = document.createElement("div");
      art.className = "boss-art";
      art.setAttribute("aria-hidden", "true");
      art.innerHTML = cookie
        ? '<span class="monster-eye"></span><span class="monster-eye"></span><span class="monster-mouth"></span>'
        : '<span class="video-play">▶</span><span class="video-caption">SPONSORED BY ABSOLUTELY NOBODY</span><i class="video-scan"></i>';
      t.el.querySelector(".target-body")?.prepend(art);
      if (!cookie) {
        const timeline = document.createElement("div");
        timeline.className = "video-timeline";
        timeline.innerHTML = '<i id="video-clock"></i>';
        panel.append(timeline);
      }
      const hint = document.createElement("p");
      hint.className = "boss-hint";
      hint.textContent = cookie
        ? "Break the 3 cookie shields. Then smash the monster."
        : "Damage works only during the green “SKIP WINDOW”.";
      panel.append(hint);
      this.container.append(panel);
      this.status.textContent = cookie
        ? "BOSS: Break all three cookie shields, then attack."
        : "BOSS: Wait for the green skip window, then attack.";
    } else {
      for (let i = 0; i < waveCount(this.wave); i++) {
        const ad = fictionalAds[(i + this.wave - 1) % fictionalAds.length];
        const t = this.makeTarget(ad[2], ad[3], ad[0], 55 + this.wave * 7);
        t.el.querySelector(".target-icon")!.textContent = ad[1];
        t.el.querySelector("small")!.textContent = ad[4];
        t.el.querySelector(".fake-cta")!.textContent = ad[5];
        this.container.append(t.el);
      }
      this.status.textContent = `Wave ${this.wave}. Destroy every fictional ad to move on.`;
    }
    this.place();
  }
  makeTarget(
    title: string,
    subtitle: string,
    color: string,
    hp: number,
    boss?: "cookie" | "video",
  ) {
    const el = document.createElement("button");
    el.className = `target${boss ? " boss" : ""}`;
    el.style.background = color;
    el.setAttribute("aria-label", `Attack fictional ${title}`);
    el.innerHTML =
      '<span class="target-head"><span>FICTIONAL GAME AD</span><span aria-hidden="true">×</span></span><div class="target-body"><span class="target-icon" aria-hidden="true">' +
      (boss === "cookie" ? "🍪" : boss ? "▶" : "✦") +
      '</span><strong></strong><strong class="subtitle"></strong><small></small><span class="fake-cta" aria-hidden="true">SMASH THIS FAKE AD</span></div><progress aria-label="Target health"></progress>';
    el.querySelector("strong")!.textContent = title;
    el.querySelector(".subtitle")!.textContent = subtitle;
    const p = el.querySelector("progress")!;
    p.max = hp;
    p.value = hp;
    const target: Target = {
      id: this.targets.length,
      hp,
      max: hp,
      el,
      boss,
      x: 0,
      y: 0,
      kick: 0,
      born: this.elapsed,
    };
    el.style.setProperty("--card-color", color);
    const cracks = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "svg",
    );
    cracks.setAttribute("viewBox", "0 0 100 100");
    cracks.setAttribute("preserveAspectRatio", "none");
    cracks.setAttribute("aria-hidden", "true");
    cracks.classList.add("cracks");
    el.append(cracks);
    this.targets.push(target);
    el.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || !this.running || this.paused) return;
      e.preventDefault();
      this.release();
      this.keyboardAim = false;
      const r = this.arena.getBoundingClientRect();
      this.fx.pointer = {
        x: e.clientX - r.left,
        y: e.clientY - r.top,
        visible: e.pointerType !== "touch",
        touch: e.pointerType === "touch",
      };
      el.focus({ preventScroll: true });
      el.setPointerCapture?.(e.pointerId);
      this.held = target;
      this.attack(target);
      if (this.weapon === "chainsaw") {
        el.classList.add("cutting");
        this.sfx.loop(true);
        this.fx.cutting = true;
      }
    });
    el.addEventListener("lostpointercapture", () => this.release());
    el.addEventListener("click", (e) => {
      if (e.detail === 0) this.attack(target);
    });
    return target;
  }
  release() {
    this.held?.el.classList.remove("cutting");
    this.held = null;
    this.sfx.loop(false);
    this.fx.cutting = false;
  }
  attack(t: Target, blast = false) {
    if (
      !this.running ||
      this.paused ||
      t.hp <= 0 ||
      (!blast && this.elapsed - this.lastAttack < cooldown[this.weapon])
    )
      return;
    this.lastAttack = this.elapsed;
    if (
      t.boss &&
      !bossCanTakeDamage(t.boss, this.shields, this.elapsed - this.bossStarted)
    ) {
      this.status.textContent =
        t.boss === "cookie"
          ? "Shielded! Break Tracking, Partners, and Personalization first."
          : "Unskippable means unskippable. Wait for the green window.";
      this.sfx.hit("hammer");
      t.kick = 8;
      return;
    }
    const a = this.arena.getBoundingClientRect(),
      r = t.el.getBoundingClientRect();
    const x = r.left - a.left + r.width / 2,
      y = r.top - a.top + r.height / 2;
    this.shots++;
    t.hp = Math.max(0, t.hp - (blast ? 90 : damage[this.weapon]));
    this.rage = blast
      ? this.rage
      : Math.min(100, this.rage + (t.hp === 0 ? 18 : 6));
    t.el.querySelector("progress")!.value = t.hp;
    t.kick = this.weapon === "hammer" ? 18 : 5;
    t.el.classList.add("damaged");
    if (this.weapon === "laser") t.el.classList.add("burnt");
    const px =
      this.fx.pointer.visible || this.fx.pointer.touch
        ? Math.max(
            r.left - a.left,
            Math.min(r.right - a.left, this.fx.pointer.x),
          )
        : x;
    const py =
      this.fx.pointer.visible || this.fx.pointer.touch
        ? Math.max(r.top - a.top, Math.min(r.bottom - a.top, this.fx.pointer.y))
        : y;
    this.fx.hit(px, py, t.el.style.background, this.weapon, t.hp === 0);
    this.sfx.hit(this.weapon, t.hp === 0);
    if (this.weapon === "chainsaw" && !this.reduced)
      try {
        navigator.vibrate?.(12);
      } catch {}
    const cracks = t.el.querySelector(".cracks")!;
    if (cracks.childElementCount < 8) {
      const cx = r.width ? ((px - (r.left - a.left)) / r.width) * 100 : 50,
        cy = r.height ? ((py - (r.top - a.top)) / r.height) * 100 : 50;
      const path = document.createElementNS(
        "http://www.w3.org/2000/svg",
        "path",
      );
      path.setAttribute(
        "d",
        `M${cx - 24},${cy - 32} L${cx - 9},${cy - 10} L${cx},${cy} L${cx + 18},${cy + 26} M${cx - 9},${cy - 10} L${cx + 10},${cy - 22} M${cx},${cy} L${cx - 22},${cy + 18}`,
      );
      cracks.append(path);
    }
    if (t.hp === 0) {
      const hadFocus = document.activeElement === t.el;
      this.combo = nextCombo(this.combo, this.lastHit, this.elapsed);
      this.lastHit = this.elapsed;
      const points = scoreFor(this.combo, !!t.boss);
      this.score += points;
      this.kills++;
      this.bestCombo = Math.max(this.bestCombo, this.combo);
      this.fx.shatter(t.el, x, y, r.width, r.height, this.weapon);
      this.fx.label(x, y, `+${points}`, t.el.style.background);
      if (this.combo >= 3) {
        this.fx.label(
          a.width / 2,
          70,
          [
            "",
            "",
            "",
            "TRIPLE DELETE",
            "ABSOLUTE MENACE",
            "ADPOCALYPSE",
            "NO MERCY",
            "BROWSER BERSERKER",
            "INTERNET EXORCIST",
          ][this.combo] || "OVERKILL",
          "#d8ff3e",
          true,
        );
        this.sfx.cue("combo");
      }
      if (t.boss) this.announce("BOSS OBLITERATED", true);
      this.remaining = Math.min(
        120000,
        this.remaining + (t.boss ? 8000 : 1000),
      );
      t.el.hidden = true;
      if (this.held === t) this.release();
      track(
        t.boss ? "boss_defeated" : "ad_destroyed",
        t.boss ? { boss: t.boss } : { weapon: this.weapon },
      );
      this.status.textContent = t.boss
        ? "BOSS DEFEATED. Your browser can breathe again."
        : `DESTROYED. ${this.combo > 1 ? `×${this.combo} combo!` : "Keep going."}`;
      if (this.targets.every((x) => x.hp === 0)) {
        this.pendingWave = this.wave + 1;
        this.transitionAt = this.elapsed + 850;
        if (!t.boss) this.announce("WAVE CLEARED", false);
        this.container.querySelector(".boss-shields")?.remove();
        this.container.querySelector("#boss-phase")?.remove();
      }
      const next = this.targets.find((x) => x.hp > 0);
      if (hadFocus) next?.el.focus({ preventScroll: true });
    }
    this.updateHud();
  }
  announce(text: string, boss = false) {
    if (!this.stage) return;
    this.stage.textContent = text;
    this.stage.classList.toggle("boss-call", boss);
    this.stage.classList.add("visible");
    this.announceUntil = this.elapsed + 1150;
  }
  rageBlast() {
    if (!this.running || this.paused || this.rage < 100) return;
    const eligible = this.targets.filter(
      (t) =>
        t.hp > 0 &&
        (!t.boss ||
          bossCanTakeDamage(
            t.boss,
            this.shields,
            this.elapsed - this.bossStarted,
          )),
    );
    if (!eligible.length) {
      this.status.textContent =
        "Rage ready. Break the shields or wait for the skip window first.";
      return;
    }
    this.rage = 0;
    this.fx.shockwave();
    this.sfx.cue("rage");
    this.announce("RAGE DETONATED");
    for (const t of eligible) this.attack(t, true);
    this.updateHud();
  }
  motion(delta: number) {
    if (this.reduced) return;
    for (const t of this.targets) {
      if (t.hp <= 0) continue;
      const held =
        this.held === t ||
        (this.keyboardAim && document.activeElement === t.el);
      if (held) continue;
      const m = targetMotion(
        this.elapsed - this.bossStarted,
        t.id,
        this.wave,
        this.arena.clientWidth < 600,
        held,
      );
      t.kick *= Math.pow(0.78, delta / 16);
      if (t.boss) {
        const panel = t.el.closest<HTMLElement>(".boss-panel");
        if (panel) panel.style.marginLeft = m.x * 0.35 + "px";
        t.el.style.transform = `rotate(${m.angle}deg) translateY(${m.y + t.kick * 0.2}px)`;
      } else
        t.el.style.transform = `translate(${m.x}px,${m.y - t.kick}px) rotate(${m.angle}deg)`;
    }
  }
  tick(timestamp: number) {
    if (!this.running || this.paused) return;
    const delta = this.previous ? Math.min(timestamp - this.previous, 80) : 0;
    this.previous = timestamp;
    this.remaining = Math.max(0, this.remaining - delta);
    this.elapsed += delta;
    if (this.held && this.weapon === "chainsaw") this.attack(this.held);
    this.motion(delta);
    if (this.stage && this.elapsed > this.announceUntil)
      this.stage.classList.remove("visible");
    if (this.combo > 1 && this.elapsed - this.lastHit > 2200) this.combo = 1;
    if (this.remaining <= 0) {
      this.finish(false);
      return;
    }
    if (this.pendingWave && this.elapsed >= this.transitionAt) {
      if (this.pendingWave > 6) {
        this.finish(true);
        return;
      }
      this.wave = this.pendingWave;
      this.spawnWave();
    }
    const phase = document.querySelector("#boss-phase");
    if (phase) {
      const open =
        this.wave === 3
          ? this.shields === 0
          : videoVulnerable(this.elapsed - this.bossStarted);
      this.arena.classList.toggle("boss-open", open);
      const clock = document.querySelector<HTMLElement>("#video-clock");
      if (clock)
        clock.style.width = `${((this.elapsed - this.bossStarted) % 4200) / 42}%`;
      const label = open
        ? "OPEN — SMASH NOW!"
        : this.wave === 3
          ? `${this.shields} SHIELDS REMAIN`
          : "UNSKIPPABLE — WAIT FOR GREEN";
      if (label !== this.bossPhase) {
        phase.textContent = label;
        phase.classList.toggle("shielded", !open);
        this.bossPhase = label;
      }
    }
    this.fx.draw(Math.min(delta, 40));
    const shake = this.reduced ? 0 : this.fx.shake;
    this.container.style.transform = shake
      ? `translate(${Math.sin(this.elapsed * 0.07) * shake}px,${Math.cos(this.elapsed * 0.1) * shake * 0.6}px)`
      : "";
    this.updateHud();
    this.frame = requestAnimationFrame((t) => this.tick(t));
  }
  updateHud() {
    if (this.renderedScore !== this.score) {
      document.querySelector("#score")!.textContent = String(
        this.score,
      ).padStart(5, "0");
      this.renderedScore = this.score;
    }
    const combo = document.querySelector("#combo")!;
    if (combo.textContent !== `×${this.combo}`)
      combo.textContent = `×${this.combo}`;
    combo.classList.toggle("combo-hot", this.combo >= 3);
    document.querySelector("#wave")!.textContent = `${this.wave} / 6`;
    const meter = document.querySelector<HTMLElement>("#rage-fill");
    if (meter) meter.style.width = this.rage + "%";
    const rageValue = document.querySelector("#rage-value");
    if (rageValue) rageValue.textContent = Math.floor(this.rage) + "%";
    if (this.rageButton) {
      this.rageButton.disabled =
        this.rage < 100 || !this.running || this.paused;
      this.rageButton.classList.toggle("ready", this.rage >= 100);
    }
    const chain = document.querySelector<HTMLElement>("#combo-fill");
    if (chain)
      chain.style.transform = `scaleX(${this.combo > 1 ? Math.max(0, 1 - (this.elapsed - this.lastHit) / 2200) : 0})`;
    const time = document.querySelector("#time")!;
    const seconds = String(Math.ceil(this.remaining / 1000));
    if (time.textContent !== seconds) time.textContent = seconds;
  }
  togglePause() {
    if (!this.running) return;
    this.release();
    this.paused = !this.paused;
    const button = document.querySelector("#pause")!;
    button.textContent = this.paused ? "Resume" : "Pause";
    this.updateHud();
    if (this.paused) {
      cancelAnimationFrame(this.frame);
      this.status.textContent = "Paused. Press Resume or Escape to continue.";
    } else {
      this.previous = 0;
      this.frame = requestAnimationFrame((t) => this.tick(t));
      this.status.textContent = "Back to demolition.";
    }
  }
  finish(won: boolean) {
    this.running = false;
    this.release();
    cancelAnimationFrame(this.frame);
    document.querySelector<HTMLButtonElement>("#pause")!.disabled = true;
    this.fx.pointer.visible = false;
    this.updateHud();
    this.stage?.classList.remove("visible");
    if (won) this.sfx.cue("win");
    track("game_completed", {
      score: this.score,
      result: won ? "won" : "time_up",
    });
    this.overlay.hidden = false;
    this.overlay.innerHTML = `<span class="eyebrow">${won ? "INTERNET REPAIRED. FOR NOW." : "THE INTERNET FOUGHT BACK."}</span><h3>${won ? "YOU DELETED THE NOISE." : "TIME’S UP. RAGE ON."}</h3><p>Final score <strong class="lime">${this.score.toLocaleString()}</strong> · Wave ${this.wave} / 6</p><div class="result-stats"><span><b>${this.kills}</b> ADS DELETED</span><span><b>×${this.bestCombo}</b> BEST COMBO</span><span><b>${this.bestCombo >= 6 ? "S" : "A"}</b> CHAOS RANK</span></div><div class="demo-actions"><button class="primary" id="play-again">SMASH AGAIN ↻</button><button id="share">Share score ↗</button></div><p class="small" id="share-status" role="status"></p>`;
    this.overlay
      .querySelector("#play-again")!
      .addEventListener("click", () => this.start());
    this.overlay
      .querySelector("#share")!
      .addEventListener("click", () => void this.share());
    this.overlay
      .querySelector<HTMLButtonElement>("#play-again")!
      .focus({ preventScroll: true });
    this.status.textContent = won
      ? "Completed all six waves. Both bosses defeated."
      : "Time is up. Try another weapon and restart.";
  }
  async share() {
    const text = `I scored ${this.score.toLocaleString()} in AD DESTROYER. The internet is broken. Fix it with a hammer.`;
    const url = new URL(sitePath("/"), location.href).href;
    const status = this.overlay.querySelector("#share-status")!;
    try {
      if (navigator.share) {
        await navigator.share({ title: "AD DESTROYER", text, url });
        status.textContent = "Score shared.";
        track("score_shared", { method: "web_share" });
      } else {
        await navigator.clipboard.writeText(`${text} ${url}`);
        status.textContent = "Score copied. Paste it anywhere.";
        track("score_shared", { method: "clipboard" });
      }
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") {
        status.textContent = "Share canceled.";
        return;
      }
      status.textContent = "Copy your score from the box below.";
      if (!this.overlay.querySelector("textarea")) {
        const field = document.createElement("textarea");
        field.className = "copy-area";
        field.readOnly = true;
        field.setAttribute("aria-label", "Score text to copy");
        field.value = `${text} ${url}`;
        this.overlay.append(field);
        field.focus();
        field.select();
      }
    }
  }
}
