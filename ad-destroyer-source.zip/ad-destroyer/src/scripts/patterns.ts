const cards = document.querySelectorAll<HTMLElement>("[data-pattern]");
let seconds = 10;
let interval: ReturnType<typeof setInterval> | undefined;
const timer = () => {
  seconds--;
  if (seconds < 0) seconds = 10;
  cards.forEach((card) => {
    const el = card.querySelector("[data-timer]");
    if (el && !card.classList.contains("destroyed"))
      el.textContent = `00:${String(seconds).padStart(2, "0")}`;
  });
};
function run() {
  if (interval === undefined) interval = setInterval(timer, 1000);
}
function stop() {
  if (interval !== undefined) clearInterval(interval);
  interval = undefined;
}
run();
document.addEventListener("visibilitychange", () =>
  document.hidden ? stop() : run(),
);
window.addEventListener("pagehide", stop);
const responses: Record<string, string> = {
  reset:
    "The “deadline” restarted. A resettable timer is pressure, not proof of a real expiring offer.",
  bait: "Bait spotted. This large button represented an unrelated imaginary bundle. Nothing downloaded.",
  file: "You found the intended action, hidden beneath the promotional button. No file was downloaded.",
  accept:
    "You chose the highlighted option. Visual emphasis and flattering labels can steer this decision. No preference was stored.",
  decline:
    "Declining is a valid choice. Guilt or a hard-to-find button should not make it harder. Nothing was stored.",
  stay: "The highlighted action keeps you in the fictional list. No email subscription exists.",
  noise: "An unrelated link adds noise while the exit is harder to find.",
  exit: "You found the unsubscribe action. It should have been easy to find in the first place.",
  refresh:
    "Stock is now “Only 1 imaginary item left!” No inventory was checked. This is a fabricated scarcity claim.",
  "fair-choice":
    "Choice acknowledged. This is a fair-design demonstration; no real action or preference was saved.",
};
cards.forEach((card) => {
  const bad = card.querySelector<HTMLElement>(".bad-example")!,
    fair = card.querySelector<HTMLElement>(".fair-example")!,
    output = card.querySelector<HTMLElement>(".pattern-output")!,
    toggle = card.querySelector<HTMLButtonElement>('[data-action="fair"]')!,
    smash = card.querySelector<HTMLButtonElement>('[data-action="smash"]')!,
    restore = card.querySelector<HTMLButtonElement>('[data-action="restore"]')!;
  card.querySelectorAll<HTMLButtonElement>("[data-action]").forEach((b) =>
    b.addEventListener("click", () => {
      const action = b.dataset.action!;
      if (action === "fair") {
        fair.hidden = !fair.hidden;
        toggle.setAttribute("aria-expanded", String(!fair.hidden));
        toggle.textContent = fair.hidden
          ? "Show a fair alternative"
          : "Hide fair alternative";
        return;
      }
      if (action === "smash") {
        bad.hidden = true;
        card.classList.add("destroyed");
        smash.hidden = true;
        restore.hidden = false;
        fair.hidden = false;
        toggle.setAttribute("aria-expanded", "true");
        toggle.textContent = "Hide fair alternative";
        output.textContent =
          "Manipulation removed. The fair alternative gives you a clearer choice.";
        restore.focus({ preventScroll: true });
        return;
      }
      if (action === "restore") {
        bad.hidden = false;
        card.classList.remove("destroyed");
        smash.hidden = false;
        restore.hidden = true;
        output.textContent = "Demo reset. Try the controls above.";
        seconds = 10;
        const stock = card.querySelector("[data-stock]");
        if (stock) stock.textContent = "Only 2 imaginary items left!";
        smash.focus({ preventScroll: true });
        return;
      }
      if (action === "reset") seconds = 10;
      if (action === "refresh")
        card.querySelector("[data-stock]")!.textContent =
          "Only 1 imaginary item left!";
      output.textContent = responses[action] ?? "Demo action acknowledged.";
    }),
  );
});

export {};
