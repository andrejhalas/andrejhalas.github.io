import { sitePath } from "../scripts/paths";
import type {APIRoute} from 'astro';
export const GET:APIRoute=({site})=>new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${['/','/fake-virus-popup/','/popup-blocker-test/','/dark-pattern-examples/','/privacy/'].map(path=>`<url><loc>${new URL(sitePath(path),site).href}</loc></url>`).join('')}</urlset>`,{headers:{'Content-Type':'application/xml'}});
