import { sitePath } from "../scripts/paths";
import type {APIRoute} from 'astro';
export const GET:APIRoute=({site})=>new Response(`User-agent: *\n${site!.hostname==='localhost'?'Disallow: /':`Allow: /\nDisallow: ${sitePath('/popup-test-window/')}`}\nSitemap: ${new URL(sitePath('/sitemap.xml'),site).href}\n`,{headers:{'Content-Type':'text/plain'}});
