import { defineConfig } from "astro/config";
const site = process.env.SITE_URL || "http://localhost:4321";
const parsed = new URL(site);
if (parsed.pathname !== "/" || !["http:", "https:"].includes(parsed.protocol))
  throw new Error("SITE_URL must be an absolute origin");
export default defineConfig({
  site: parsed.origin,
  base: process.env.SITE_BASE_PATH || "/",
  output: "static",
  build: { assets: "assets" },
  trailingSlash: "always",
});
